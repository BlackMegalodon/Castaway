Start the RPG tutorial here:

https://youtu.be/1J5EydrnIPs

Markdown link:

[Click here in Code Editor 2](https://youtu.be/1J5EydrnIPs)