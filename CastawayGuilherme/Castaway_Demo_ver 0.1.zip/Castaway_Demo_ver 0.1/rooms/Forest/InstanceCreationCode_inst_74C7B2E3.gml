playerX=2
playerY=220