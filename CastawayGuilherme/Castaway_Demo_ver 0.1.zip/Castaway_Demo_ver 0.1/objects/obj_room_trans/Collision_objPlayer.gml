
if (counter<40) {
	counter+=1
}

with (obj_fade) {
    fade_dir = 1;
    fade_speed = 0.02;
}

if (counter==40) {
	 with (obj_fade) {
    room_goto(obj_room_trans.targetroom)
    fade_dir = -1;
    fade_speed = 0.02; // mais rápido ou mais lento
}
	global.just_teleported = true
}
//objPlayer.can_move=false