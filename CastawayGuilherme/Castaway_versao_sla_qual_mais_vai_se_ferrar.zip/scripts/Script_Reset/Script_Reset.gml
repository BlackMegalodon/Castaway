function Script_Reset() {
    var file = "save.ini";
    if (file_exists(file)) {
        file_delete(file);
    }
}
