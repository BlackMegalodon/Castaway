global.topics = {};

global.topics[$ "1"] = [
	TEXT("Bragante"),
	TEXT("Faça Sprites de DIALOGO"),
	TEXT("Kendy....."),
	TEXT("Mande o SCRIPT!"),
	TEXT("Opa foi mal ai tava tendo um ataque de esquizofrenia")
]