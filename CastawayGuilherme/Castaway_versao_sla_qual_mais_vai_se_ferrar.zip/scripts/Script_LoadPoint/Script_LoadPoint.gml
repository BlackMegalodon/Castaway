/*function Script_LoadPoint() {
    if (file_exists("save.ini")) {
        ini_open("save.ini");

        var saved_room_name = ini_read_string("Jogador", "RoomName", room_get_name(room));
        var saved_room = asset_get_index(saved_room_name);
        var saved_x = ini_read_real("Jogador", "X", 0);
        var saved_y = ini_read_real("Jogador", "Y", 0);

        objPlayer.hp = ini_read_real("Jogador", "HP", objPlayer.hp);
        objPlayer.level = ini_read_real("Jogador", "Level", objPlayer.level);
        objPlayer.gold = ini_read_real("Jogador", "Gold", objPlayer.gold);
        global.player_Name = ini_read_string("Jogador", "Nome", "SemNome");

        ini_close();

        // Muda de sala se for necessário
        if (room != saved_room) {
            room_goto(saved_room);
        } else {
            objPlayer.x = saved_x;
            objPlayer.y = saved_y;
        }
    }
}*/

function Script_LoadPoint() {
    if (file_exists("save.ini")) {
        ini_open("save.ini");

        var saved_room_name = ini_read_string("Jogador", "RoomName", room_get_name(room));
        var saved_room = asset_get_index(saved_room_name);

        var saved_x = ini_read_real("Jogador", "X", 0);
        var saved_y = ini_read_real("Jogador", "Y", 0);

        objPlayer.hp = ini_read_real("Jogador", "HP", objPlayer.hp);
        objPlayer.level = ini_read_real("Jogador", "Level", objPlayer.level);
        objPlayer.gold = ini_read_real("Jogador", "Gold", objPlayer.gold);
        global.player_Name = ini_read_string("Jogador", "Nome", "");

        ini_close();

        // Só muda de sala se o nome for válido
        if (saved_room != -1 && room != saved_room) {
            room_goto(saved_room);
        } else {
            objPlayer.x = saved_x;
            objPlayer.y = saved_y;
        }
    }
}

