function Script_Load(){
if (room != global.saved_room) {
        room_goto(global.saved_room);
    } else {
        objPlayer.x = global.saved_x;
        objPlayer.y = global.saved_y;
    }
}