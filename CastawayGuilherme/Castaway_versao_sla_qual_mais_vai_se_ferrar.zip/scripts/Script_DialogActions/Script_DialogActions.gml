#macro TEXT new TextAction

function DialogAction() constructor {
	act = function() {};
}

function TextAction(_text) : DialogAction() constructor {
	text = _text;
	
	act = function(textbox) {
		textbox.setText(text);
	}
}