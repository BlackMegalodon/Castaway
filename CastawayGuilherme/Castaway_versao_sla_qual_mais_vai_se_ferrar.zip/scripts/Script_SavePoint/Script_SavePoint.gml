function Script_SavePoint() {
   
    
    
    ini_open("save.ini");

    ini_write_string("Jogador", "RoomName", room_get_name(room)); // <- IMPORTANTE PRA CARAMBA????
    ini_write_real("Jogador", "X", objPlayer.x);
    ini_write_real("Jogador", "Y", objPlayer.y);
    ini_write_real("Jogador", "HP", objPlayer.hp);
    ini_write_real("Jogador", "Level", objPlayer.level);
    ini_write_real("Jogador", "Gold", objPlayer.gold);
    ini_write_string("Jogador", "Nome", global.player_Name);

    ini_close();


}
 /*ini_open("save.ini");

    ini_write_real("Jogador", "X", objPlayer.x);
    ini_write_real("Jogador", "Y", objPlayer.y);
    ini_write_string("Jogador", "RoomName", room_get_name(room));
    ini_write_real("Jogador", "HP", objPlayer.hp);
    ini_write_real("Jogador", "Level", objPlayer.level);
    ini_write_real("Jogador", "Gold", objPlayer.gold);
    ini_write_string("Jogador", "Nome", global.player_Name); // se quiser salvar nome

    ini_close();*/