function Script_Save(){
    global.saved_x = objPlayer.x;
    global.saved_y = objPlayer.y;
    global.saved_room = room;
	global.saved_hp = objPlayer.hp;
	global.saved_lv = objPlayer.level;
	global.saved_gold = objPlayer.gold;
  //  global.saved_name=global.player_Name;
}