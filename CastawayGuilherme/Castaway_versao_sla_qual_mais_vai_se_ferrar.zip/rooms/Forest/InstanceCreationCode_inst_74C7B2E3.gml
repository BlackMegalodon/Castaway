playerX=2
playerY=220
objPlayer.x=2;
objPlayer.y=220;