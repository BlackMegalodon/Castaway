targetroom= Trifucation_Plains
global.PlayerCordx=3;
global.PlayerCordy=590