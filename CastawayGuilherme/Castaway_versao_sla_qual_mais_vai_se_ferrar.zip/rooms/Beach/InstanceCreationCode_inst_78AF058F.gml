playerX=235
playerY=6