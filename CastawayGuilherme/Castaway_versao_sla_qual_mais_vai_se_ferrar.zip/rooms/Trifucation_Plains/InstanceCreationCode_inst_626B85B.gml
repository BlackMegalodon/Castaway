targetroom=ForestEntrance;
global.PlayerCordx=3
global.PlayerCordy=251