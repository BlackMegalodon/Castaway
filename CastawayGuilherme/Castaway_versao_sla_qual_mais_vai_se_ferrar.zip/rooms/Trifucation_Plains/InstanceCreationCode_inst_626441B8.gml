targetroom=Plains
global.PlayerCordx=1255;
global.PlayerCordy=639