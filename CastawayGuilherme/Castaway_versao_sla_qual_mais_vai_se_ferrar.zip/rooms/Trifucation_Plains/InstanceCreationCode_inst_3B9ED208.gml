playerX=3;

playerY=586;

//objPlayer.x=3;
//objPlayer.y=590;

