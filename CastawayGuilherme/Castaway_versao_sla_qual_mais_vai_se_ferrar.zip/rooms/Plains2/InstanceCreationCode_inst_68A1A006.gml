playerX=35
playerY=650