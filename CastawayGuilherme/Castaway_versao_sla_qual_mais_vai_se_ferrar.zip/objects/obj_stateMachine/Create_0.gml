enum states{
neutro,
interagindo,
estadoQueEvaporaOPlayerDaExistencia,
batata,
transicaoDeBatata
};


enum gray_states{
	follow,
	crawling,
	neutro
	
};


enum battle_states{
	turnoPlayer,
	turnoInimigo
};

enum player_menu_state {
    escolher_coluna,
    menu_ataques,
    menu_gray,
	player_hit,
	gray_hit
}

enum turnoPlayer{
	neutro,
	PlayerSelect,
	
};
enum turnoGray{
	neutro,
	GraySelect
}