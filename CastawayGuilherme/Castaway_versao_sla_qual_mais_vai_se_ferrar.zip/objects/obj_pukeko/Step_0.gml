if (global.Bubble_HP<=40) {
	global.can_spare=1;
}
if (global.Bubble_HP<=0) {
    
	//instance_destroy(obj_BubleBee);
    	//Script_Load();

    
}
if (global.Turnos==0) {
	CU=0;
    atkPerTurn+=1;
}

if (atkPerTurnResult==4) {
	atkPerTurnResult=1
}

if (atkPerTurn==0) {
	//atkPerTurnResult+=1;
}


if (global.Turnos ==1 ){
    

atkPerTurn=0;
ataque_timer += 1;

    if (global.Timer>0) {
    	global.Timer-=1
    

if (ataque_timer >= ataque_tempo) {
    // Criar o ataque
   
	/*var atk = instance_create_layer(569, 173, "Instances", obj_bulletCerberus_1);
	var dir = point_direction(x, y, OBJ_SOUL.x + 70, OBJ_SOUL.y);
	atk.direction = dir;
	atk.speed = 6;
	var atk2 = instance_create_layer(529, 163, "Instances", obj_bulletCerberus_1);
	var dir2 = point_direction(x, y, OBJ_SOUL.x + 70, OBJ_SOUL.y);
	atk2.direction = dir;
	atk2.speed = 6;
	var atk3 = instance_create_layer(615, 209, "Instances", obj_bulletCerberus_1);
	var dir3 = point_direction(x, y, OBJ_SOUL.x + 70, OBJ_SOUL.y);
	atk3.direction = dir;
	atk3.speed = 6;*/
// CU=0;   
if (CU==0){
    if (atkPerTurnResult==0) {
    	
 /*   
 var bubblecirc_1 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_1.angle=0;
 
  var bubblecirc_2 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_2.angle=45;
 
  var bubblecirc_3 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_3.angle=90;
 
  var bubblecirc_4 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_4.angle=135;
 
  var bubblecirc_5 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_5.angle=180;
 
  var bubblecirc_6 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_6.angle=225;
 
  var bubblecirc_7 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_7.angle=270;
 
  var bubblecirc_8 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_8.angle=315;*/
        
        
     var damn = instance_create_layer(585,40,"Instances",obj_kamikazeBubble_2);
	 var damn_2 = instance_create_layer(585+50,40-150,"Instances",obj_kamikazeBubble_2);
	  var damn_3 = instance_create_layer(585,40-300,"Instances",obj_kamikazeBubble_2);
     // var damn_32 = instance_create_layer(285,40-300,"Instances",obj_pukekoSniper);
	   var damn_4 = instance_create_layer(585+50,40-450,"Instances",obj_kamikazeBubble_2);
      
	   
	        var damn1 = instance_create_layer(585,40-600,"Instances",obj_kamikazeBubble_2);
			 //var damn_21 = instance_create_layer(585+50,40-750,"Instances",obj_kamikazeBubble);
         var damn_21 = instance_create_layer(585+300,40-750,"Instances",obj_pukekoSniper);
			  var damn_31 = instance_create_layer(585,40-900,"Instances",obj_kamikazeBubble_2);
			   var damn_41 = instance_create_layer(585+50,40-1050,"Instances",obj_kamikazeBubble_2);
	  
        
        obj_battlebox.left =600;
        obj_battlebox.right=680;
		obj_battlebox.top=251
       
 CU=1;
        global.atk_enemy = Obj_staeller_slashAlert;
        
        global.Timer = 300*3-60//60==1segundo
        
    };
    
    
if (atkPerTurnResult==2) {
    
      // cria um controlador apontando para o player, por exemplo nas mãos do Asriel
var c = instance_create_layer(x+400, y, "Instances", Pukeko_Rifle); 
   
c.target = OBJ_SOUL;
c.pattern = "spread";
c.shoot_count = 7;
c.spread_angle = 60;
c.charge_time = 45;
c.bullet_speed = 4;
c.bullet_life = 200;
    
 var f = instance_create_layer(x-100, y, "Instances", Pukeko_Rifle);
f.target = OBJ_SOUL;
f.pattern = "spread";
f.shoot_count = 7;
f.spread_angle = 60;
f.charge_time = 10;
f.bullet_speed = 1;
f.bullet_life = 200;
    
   // instance_create_layer(x, y, "Instances", obj_blaster_rain_controller);

    CU=1;
    global.atk_enemy = objRapier_1; 
     global.Timer = 60*11//60==1segundo
}
    
    
    
    if (atkPerTurnResult==3) {
    
    
    instance_create_layer(x, y, "Instances", obj_blaster_rain_controller);

        
        obj_battlebox.left = -6;
        obj_battlebox.right=1284;
		obj_battlebox.top=-2.90
        obj_battlebox.bottom=725
        
        
    CU=1;
        
    global.atk_enemy = obj_blaster_rain_controller; 
     global.Timer = 60*21//60==1segundo
}
    
    
 };
//-----------------------------------------------------------------

    // Reiniciar o timer com novo tempo aleatório
    ataque_timer = 0;
	global.PlayerTurn = true;
       ataque_tempo = irandom_range(30, 31); // Novo tempo entre ataques

}
        
}
}
        

    
