ataque_tempo = irandom_range(1,2); // Tempo entre ataques (em frames)
ataque_timer = 0;
global.Bubblebee_maxHP = 600;

global.atk_enemy = obj_bulletBubble;
global.atk_enemy2 = objRapier_1;
global.Bubble_HP=300;//Bubblebee_HP;
global.Bubble_Name = "  Pukeko";

CU=0;
atkPerTurn=0;
atkPerTurnResult=0;//numero do ataque na ordem

act1 = "* Estourar"
act2 = "* Zumbir"
act3 = " "

sprite_index= Stealler;