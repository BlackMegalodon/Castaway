fade_alpha = 0;
fade_speed = 0.05;
fade_dir = 0; // 1 = fade in, -1 = fade out, 0 = nenhum
