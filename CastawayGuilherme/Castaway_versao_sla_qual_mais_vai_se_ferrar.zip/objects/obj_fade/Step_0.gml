if (fade_dir != 0) {
    fade_alpha += fade_speed * fade_dir;
    fade_alpha = clamp(fade_alpha, 0, 1);
    
    if (fade_alpha == 0 || fade_alpha == 1) {
        fade_dir = 0;
        // Aqui você pode adicionar callback, por exemplo:
        // room_goto(room_next); (após fade out)
    }
}
