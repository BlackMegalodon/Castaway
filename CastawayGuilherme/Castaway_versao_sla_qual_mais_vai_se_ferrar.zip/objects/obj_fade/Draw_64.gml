// Pegue as dimensões da câmera atual
var cam = view_camera[0]; // se usar viewport 0
var cam_x = camera_get_view_x(cam)*0;
var cam_y = camera_get_view_y(cam)*0;
var cam_w = camera_get_view_width(cam) +  10000000;
var cam_h = camera_get_view_height(cam) + 10000000;

// Configurar cor e alpha
draw_set_alpha(fade_alpha);
draw_set_color(c_black);

// Desenhar o sprite esticado para cobrir a tela
draw_sprite_stretched(spr_fade, 0, cam_x, cam_y, cam_w, cam_h);

// Resetar alpha
draw_set_alpha(1);
