if (keyboard_check_pressed(ord("Z"))) {
        	Script_SavePoint();
        }
    
     if (keyboard_check_pressed(ord("X"))) {
        	global.interaction=0;
        	instance_destroy(obj_text_Savepoint)
            instance_destroy(obj_text_Savepoint_1)
        }