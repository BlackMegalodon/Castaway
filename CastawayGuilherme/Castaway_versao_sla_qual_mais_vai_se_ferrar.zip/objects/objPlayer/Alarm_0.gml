global.just_teleported = false;
