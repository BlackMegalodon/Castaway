//room_goto(BattleRoom)
instance_create_layer(0, 0, "Instances", objTransicao);
