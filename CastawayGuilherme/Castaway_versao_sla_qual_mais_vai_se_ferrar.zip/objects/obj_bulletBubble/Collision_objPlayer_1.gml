//---------------------------------------------------
//if (!other.invincible) {
   // other.hp -= 5;
   // other.invincible = true;
   // other.invincible_timer = 120; // 60 frames = 1 segundo (ajuste como quiser)
    //other.image_alpha = 0.5; // Visualmente mostra que está invencível (opcional)
//}
//instance_destroy();
//---------------------------------------------------
