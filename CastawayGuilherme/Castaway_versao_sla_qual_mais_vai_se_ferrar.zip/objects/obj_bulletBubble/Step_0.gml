angle+= 3;
movemax+=2;

/*
if (movemax<200) {
	move+=2;

}
if (movemax>400) {
	move-=1.5;

}
if (movemax==700) {
	movemax=0;
}*/

//x = OBJ_SOUL.x-12 + lengthdir_x(80, angle);
//y = OBJ_SOUL.y-12  + lengthdir_y(80, angle);

x = 630 + move + lengthdir_x(80, angle);
y = 326  + lengthdir_y(80, angle);


if(duracaoDeTurno>0){
	 duracaoDeTurno-=1
 }
if(duracaoDeTurno==0){
instance_destroy(obj_bulletBubble);	
OBJ_SOUL.Sstate=battle_states.turnoPlayer
}