if (timer<duration) {
	timer+=1
   
}
if (timer==duration) {
	instance_create_layer(x,y,"Instances",Obj_staeller_slash);
    instance_destroy();
}