ataque_timer += 1;
//if (global.PlayerTurn==false) {
    
    if (global.Timer>0) {
    	global.Timer-=1
   // }
    
    
if (ataque_timer >= ataque_tempo) {
    // Criar o ataque
    //instance_create_layer(569, 173, "Instances", obj_bullet);
	var atk = instance_create_layer(569, 173, "Instances", obj_bulletCerberus);
	var dir = point_direction(x, y, OBJ_SOUL.x + 70, OBJ_SOUL.y);
	atk.direction = dir;
	atk.speed = 6;
	var atk2 = instance_create_layer(529, 163, "Instances", obj_bulletCerberus);
	var dir2 = point_direction(x, y, OBJ_SOUL.x + 70, OBJ_SOUL.y);
	atk2.direction = dir;
	atk2.speed = 6;
	var atk3 = instance_create_layer(615, 209, "Instances", obj_bulletCerberus);
	var dir3 = point_direction(x, y, OBJ_SOUL.x + 70, OBJ_SOUL.y);
	atk3.direction = dir;
	atk3.speed = 6;


    // Reiniciar o timer com novo tempo aleatório
    ataque_timer = 0;
	global.PlayerTurn = true;
       ataque_tempo = irandom_range(30, 50); // Novo tempo entre ataques

}
        }
        
//}