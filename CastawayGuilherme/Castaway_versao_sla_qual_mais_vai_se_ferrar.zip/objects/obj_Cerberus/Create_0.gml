ataque_tempo = irandom_range(60, 120); // Tempo entre ataques (em frames)
ataque_timer = 0;
Cerberus_HP = 200;

global.atk_enemy = obj_bulletCerberus;