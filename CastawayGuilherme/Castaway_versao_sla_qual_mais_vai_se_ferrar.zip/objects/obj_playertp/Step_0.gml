
if(counter<21){
	counter+=1;
};
if(counter==20){
	objPlayer.state=states.neutro;
};