if (timer<duration) {
	timer+=1
  // y+=10
}
if (timer==duration) {
    image_speed=0;
   
//	instance_create_layer(x,y,"Instances",Obj_staeller_slash);
   // instance_destroy();
}
if (timer==19) {
	  instance_create_layer(200,310,"Instances",obj_setalled);

}