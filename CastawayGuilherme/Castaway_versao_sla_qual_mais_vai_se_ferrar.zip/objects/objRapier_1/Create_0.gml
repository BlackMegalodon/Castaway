timer =0;
duration=20;