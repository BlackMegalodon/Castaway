timer =0;
duration=25;