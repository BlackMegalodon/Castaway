if (timer<duration) {
	timer+=1
   y+=10
}
if (timer==duration) {
	var Rapier = instance_create_layer(585,270,"Instances",objRapier_1);

    instance_destroy();
}