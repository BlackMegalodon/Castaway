//x += lengthdir_x(speed, direction);
//y += lengthdir_y(speed, direction);

// Destruir se sair da tela ou da área de batalha
//var box = instance_nearest(x, y, obj_BulletBoard);
/*if (box != noone) {
    if (x < box.x1 || x > box.x2 || y < box.y1 || y > box.y2) {
        instance_destroy();
    }
}*/
image_angle = direction + 90;