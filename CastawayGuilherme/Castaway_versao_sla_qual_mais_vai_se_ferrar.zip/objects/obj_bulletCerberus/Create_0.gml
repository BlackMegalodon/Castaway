//direction = choose(0, 45, 90, 135, 180, 225, 270, 315);
//speed = 0.5;
alarm[0] = 80; 

