/*movex-=0.1;
movemax+=1


x= x+movex
y= y-move



if (movemax<20) {
	move+=0.1;

}
if (movemax>40) {
	move-=0.1;

}
//if (movemax==12) {
//movemax=0;
//}*/

damn+=1

y -= velocidade_x;
tempo += 1;
x = y_inicial + sin(tempo * frequencia) * amplitude;

if (damn==(230)) {
	instance_create_layer(x+1,y-15,"Instances",obj_kamikazeBubble_3)
    instance_create_layer(x,y,"Instances",obj_kamikazeBubble_3)
    instance_create_layer(x+1,y+15,"Instances",obj_kamikazeBubble_3)
    instance_destroy();
}