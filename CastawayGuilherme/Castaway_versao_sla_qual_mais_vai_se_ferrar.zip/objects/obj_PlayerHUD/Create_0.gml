 instance_create_layer(192, 511, "Instances", obj_MattBtl);
  instance_create_layer(179, 500, "Instances", obj_hudBox);
   instance_create_layer(672, 500, "Instances", obj_GrayhudBox);
 instance_create_layer(687, 511, "Instances", obj_GrayBtl);
 
menu_state = player_menu_state.escolher_coluna;

selectCounter = 0;      // 0 = player / 1 = gray
verticalCounter = 0;    // opções do menu

actionSelect = turnoPlayer.neutro;
GactionSelect = turnoGray.neutro;

global.Player_Ready=false;
global.Gray_Ready=false;
