timer += 1;
if (timer >= spawn_rate) {
    timer = 0;

    // Cria múltiplas balas por vez
    for (var i = 0; i < burst_size; i++) {
        var rx = irandom_range(-32, room_width + 32);
        var ry = -16; // um pouco acima da tela
        var b = instance_create_depth(rx, ry, 0, obj_blaster_bullet);

        // direções levemente diferentes
        b.direction = irandom_range(rain_angle - spread, rain_angle + spread);
        b.speed = irandom_range(5, 10);
       // b.image_blend = make_color_hsv(irandom(0, 255), 255, 255); // cores variadas
    }
}
