spawn_rate = 4; // menor = mais rápido, maior = mais lento
timer = 0;
burst_size = 1; // quantas balas por vez
rain_angle = 270; // direção média (270 = para baixo)
spread = 20; // variação angular
