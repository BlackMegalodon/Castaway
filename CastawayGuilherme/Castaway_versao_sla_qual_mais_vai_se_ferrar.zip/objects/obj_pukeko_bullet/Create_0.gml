// obj_blaster_bullet - Create Event
speed = 30;            // velocidade base
direction = 0;        // direção inicial (em graus)
image_angle = direction;
life = 120;           // ticks antes de desaparecer
damage = 10;
homing = false;       // true/false para homing
homing_strength = 1.0; // quanto altera por step (maior = mais forte), em graus
target = noone;       // alvo para homing (geralmente obj_player)
