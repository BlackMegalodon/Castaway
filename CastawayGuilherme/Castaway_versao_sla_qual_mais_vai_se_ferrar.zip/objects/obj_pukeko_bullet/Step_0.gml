// homing (opcional)
if (homing && instance_exists(target)) {
    var tx = target.x;
    var ty = target.y;
    var desired = point_direction(x, y, tx, ty);
    // ajustar suavemente direção atual em direção 'desired'
    var diff = angle_difference(degtorad(direction), degtorad(desired)); 
    // angle_difference usa radianos; cuidamos com conversão
    // Alternativa mais simples (sem radianos):
    var delta = angle_difference(direction, desired); // se sua versão aceitar
    // aplicar homing com limitação
    if (abs(delta) > homing_strength) {
        if (delta > 0) direction += homing_strength;
        else direction -= homing_strength;
    } else direction = desired;
}

// mover
var vx = lengthdir_x(4, direction);
var vy = lengthdir_y(4, direction);
x += vx;
y += vy;

image_angle = direction;

life -= 1;
if (life <= 0) instance_destroy();

// destruir se sair da room (ajusta conforme necessário)
if (x < -100 || x > room_width + 100 || y < -100 || y > room_height + 100) instance_destroy();
