

if (global.interaction==0) {
	 instance_destroy(global.cursor_id);
}