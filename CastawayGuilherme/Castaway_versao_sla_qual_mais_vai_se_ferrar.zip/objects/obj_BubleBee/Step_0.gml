
if (OBJ_SOUL.Sstate==battle_states.turnoPlayer) {
	CU=0;
    atkPerTurn+=1;
}

if (atkPerTurnResult==3) {
	atkPerTurnResult=1
}

if (atkPerTurn==1) {
	atkPerTurnResult+=1;
}


if (OBJ_SOUL.Sstate==battle_states.turnoInimigo){
    

atkPerTurn=0;
ataque_timer += 1;

    if (global.Timer>0) {
    	global.Timer-=1
    

if (ataque_timer >= ataque_tempo) {
    // Criar o ataque
   
	/*var atk = instance_create_layer(569, 173, "Instances", obj_bulletCerberus_1);
	var dir = point_direction(x, y, OBJ_SOUL.x + 70, OBJ_SOUL.y);
	atk.direction = dir;
	atk.speed = 6;
	var atk2 = instance_create_layer(529, 163, "Instances", obj_bulletCerberus_1);
	var dir2 = point_direction(x, y, OBJ_SOUL.x + 70, OBJ_SOUL.y);
	atk2.direction = dir;
	atk2.speed = 6;
	var atk3 = instance_create_layer(615, 209, "Instances", obj_bulletCerberus_1);
	var dir3 = point_direction(x, y, OBJ_SOUL.x + 70, OBJ_SOUL.y);
	atk3.direction = dir;
	atk3.speed = 6;*/
// CU=0;   

    if (atkPerTurnResult==1) {
    	
   
 var bubblecirc_1 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_1.angle=0;
 
  var bubblecirc_2 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_2.angle=45;
 
  var bubblecirc_3 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_3.angle=90;
 
  var bubblecirc_4 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_4.angle=135;
 
  var bubblecirc_5 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_5.angle=180;
 
  var bubblecirc_6 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_6.angle=225;
 
  var bubblecirc_7 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_7.angle=270;
 
  var bubblecirc_8 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_8.angle=315;
        
 
 CU=1;
        global.atk_enemy = obj_bulletBubble;
        
        global.Timer = 60*10//60==1segundo
        
    };
    
    
if (atkPerTurnResult==2) {
    
      var Rapier = instance_create_layer(985,420,"Instances",obj_kamikazeBubble);

    CU=1;
    global.atk_enemy = obj_kamikazeBubble; 
     global.Timer = 60*6//60==1segundo
}
 
//-----------------------------------------------------------------

    // Reiniciar o timer com novo tempo aleatório
    ataque_timer = 0;
	OBJ_SOUL.Sstate=battle_states.turnoInimigo
       ataque_tempo = irandom_range(30, 31); // Novo tempo entre ataques

}
        
}
}
        

    
