//image_speed=0;

movex =0;
move=0;
movemax=0


amplitude = 0;//82 // Altura da oscilação
frequencia = 0.1; // Velocidade da oscilação
velocidade_x = -5; //4 Velocidade constante para frente
tempo = 0;
y_inicial = x;
