if (global.buttonCounter=1) {
	sprite_index = spr_atkbutton_1;
};