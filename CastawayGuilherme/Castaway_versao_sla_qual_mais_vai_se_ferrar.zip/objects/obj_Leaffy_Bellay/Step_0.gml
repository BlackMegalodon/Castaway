if (global.Bubble_HP<=40) {
	global.can_spare=1;
}
if (global.Bubble_HP<=0) {
    
	//instance_destroy(obj_BubleBee);
    	//Script_Load();

    
}
if (global.Turnos==0) {
	CU=0;
    atkPerTurn+=1;
}

if (atkPerTurnResult==3) {
	atkPerTurnResult=1
}

if (atkPerTurn==1) {
	atkPerTurnResult+=1;
}


if (global.Turnos ==1 ){
    

atkPerTurn=0;
ataque_timer += 1;

    if (global.Timer>0) {
    	global.Timer-=1
    

if (ataque_timer >= ataque_tempo) {
    // Criar o ataque
   
	/*var atk = instance_create_layer(569, 173, "Instances", obj_bulletCerberus_1);
	var dir = point_direction(x, y, OBJ_SOUL.x + 70, OBJ_SOUL.y);
	atk.direction = dir;
	atk.speed = 6;
	var atk2 = instance_create_layer(529, 163, "Instances", obj_bulletCerberus_1);
	var dir2 = point_direction(x, y, OBJ_SOUL.x + 70, OBJ_SOUL.y);
	atk2.direction = dir;
	atk2.speed = 6;
	var atk3 = instance_create_layer(615, 209, "Instances", obj_bulletCerberus_1);
	var dir3 = point_direction(x, y, OBJ_SOUL.x + 70, OBJ_SOUL.y);
	atk3.direction = dir;
	atk3.speed = 6;*/
// CU=0;   
if (CU==0){
    if (atkPerTurnResult==1) {
    	
 /*   
 var bubblecirc_1 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_1.angle=0;
 
  var bubblecirc_2 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_2.angle=45;
 
  var bubblecirc_3 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_3.angle=90;
 
  var bubblecirc_4 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_4.angle=135;
 
  var bubblecirc_5 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_5.angle=180;
 
  var bubblecirc_6 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_6.angle=225;
 
  var bubblecirc_7 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_7.angle=270;
 
  var bubblecirc_8 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
 bubblecirc_8.angle=315;*/
        
        var leaf = instance_create_layer(x+40, y, "Instances", obj_leafAttack); 
  
        
        obj_battlebox.left =490;
        obj_battlebox.right=760;
		obj_battlebox.top=351
       
 CU=1;
        global.atk_enemy = Obj_staeller_slashAlert;
        
        global.Timer = 300*2//60==1segundo
        
    };
    
    
if (atkPerTurnResult==2) {
    
 
        var leaf = instance_create_layer(x-200, y+320, "Instances", obj_pencileaf); 
  
   // instance_create_layer(x, y, "Instances", obj_blaster_rain_controller);
    obj_battlebox.left =490;
        obj_battlebox.right=760;
		obj_battlebox.top=351
    CU=1;
    global.atk_enemy = objRapier_1; 
     global.Timer = 60*11//60==1segundo
}
    
    
 };
//-----------------------------------------------------------------

    // Reiniciar o timer com novo tempo aleatório
    ataque_timer = 0;
	global.PlayerTurn = true;
       ataque_tempo = irandom_range(30, 31); // Novo tempo entre ataques

}
        
}
}
        

    
