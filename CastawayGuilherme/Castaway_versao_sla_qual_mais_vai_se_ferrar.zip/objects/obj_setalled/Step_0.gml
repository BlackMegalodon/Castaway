if (timer<duration) {
	timer+=1
    x+=6
   
}
if (timer==duration) {
	
    //instance_create_layer(200,270,"Instances",obj_setalled);

    instance_destroy();
}