timer =0;
duration=80;
waitTime=60;