if (waitTime>0) {
	waitTime-=1;
}
if (waitTime<=0) {
	

if (timer<duration) {
	timer+=1
   y+=2;
    obj_battlebox.top+=0.25
}
    
}