if (keyboard_check_pressed(ord("J"))) {
    Script_SavePoint();
}
if (keyboard_check_pressed(ord("K"))) {
    Script_LoadPoint();
}
if (!variable_global_exists("player_Name")) {
    global.player_Name = "SemNome"; // valor padrão pq por algum motivo ts tweaking
}
