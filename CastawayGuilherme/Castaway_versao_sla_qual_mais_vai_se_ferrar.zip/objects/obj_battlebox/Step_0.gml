
if (top > bottom - border_thickness) top = bottom - border_thickness;
if (left > right - border_thickness) left = right - border_thickness;




