
if (counter<36){
	counter+=1
}

with (obj_fade) {
    fade_dir = 1;
    fade_speed = 0.01;
}

if (counter==36){
	 with (obj_fade) {
    room_goto(other.targetroom)
	objPlayer.x=global.PlayerCordx
	objPlayer.y=global.PlayerCordy
    fade_dir = -1;
    fade_speed = 0.01;
//pido ou mais lento
}
	global.just_teleported = true
}
objPlayer.state=states.interagindo
