x1 = x;
y1 = y;
x2 = x + sprite_width;
y2 = y + sprite_height;
