// Se acertou ou errou, faz o blink
if (hit_registered || miss)
{
    if (blink_timer < blink_duration)
        blink_timer++;
    else
    {
      /*  // terminou animação, reseta
        hit_registered = false;
        miss = false;
        blink_timer = 0;

        pointer_x = bar_x;
        damage = 0;

        // volta pro turno inimigo (ou faz oq tu quiser)
        OBJ_SOUL.Sstate = battle_states.turnoInimigo;*/
    }
}


// Movimento só se ainda não decidiu
if (!hit_registered && !miss)
{
    pointer_x += pointer_speed;

    // Se passou do final -> MISS
    if (pointer_x >= bar_x + bar_width)
    {
        miss = true;
        damage = 0;
    }

    // Apertou espaço -> calcula dano
    if (keyboard_check_pressed(vk_space))
    {
        hit_registered = true;

        // porcentagem do ponteiro na barra
        var pct = (pointer_x - bar_x) / bar_width;

        // dano máximo no final direito
        damage = round(pct * 70);
        damage = clamp(damage, 0, 100);
		global.enemyHealthPoints -= damage
		
    }
}

 instance_create_layer(305,316, "Instances",obj_hitbar);