timer =0;
duration=40;