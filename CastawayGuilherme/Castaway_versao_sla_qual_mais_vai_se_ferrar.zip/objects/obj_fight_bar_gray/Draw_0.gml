// Barra
//draw_set_color(c_gray);
//draw_rectangle(bar_x, bar_y, bar_x + bar_width, bar_y + bar_height, false);

// Linha do centro
draw_set_color(c_red);
draw_line(bar_x + (bar_width/2)+120, bar_y, bar_x + (bar_width/2)+120, bar_y + bar_height);

// Ponteiro
//if (!hit_registered && !miss) {
    
   // Só desenha o ponteiro se ele ainda não terminou o piscar
if (!miss || blink_timer < blink_duration) {
    var outline_color = c_black;
    var fill_color = c_white;

    // Se acertou ou errou -> começa a piscar
    if ((hit_registered || miss) && (blink_timer div 6) mod 2 == 0) {
        // Inverte as cores (piscar)
        outline_color = c_white;
        fill_color = c_black;
        
        global.destroy_bar+=1;
    }
    //--------
    if (miss) {
    	global.destroy_bar+=1;
    }
    
    if (global.destroy_bar==60) {
    	instance_destroy(obj_fight_bar_gray);
		obj_PlayerHUD.menu_state=player_menu_state.escolher_coluna
		OBJ_SOUL.Sstate = battle_states.turnoInimigo;
    }

    // Contorno
    draw_set_color(outline_color);
    draw_rectangle(pointer_x - pointer_width/2 - 1, bar_y - 1,
                   pointer_x + pointer_width/2 + 1, bar_y + bar_height + 1, false);

    // Ponteiro
    draw_set_color(fill_color);
    draw_rectangle(pointer_x - pointer_width/2, bar_y,
                   pointer_x + pointer_width/2, bar_y + bar_height, false);
}



// Resultado
if (hit_registered) {
    draw_set_color(c_white);
    draw_text(bar_x, bar_y - 30, "DANO: " + string(round(damage)));
 
    
}
if (miss) {
    draw_set_color(c_white);
    draw_text(bar_x, bar_y - 30, "MISS");
    
}
