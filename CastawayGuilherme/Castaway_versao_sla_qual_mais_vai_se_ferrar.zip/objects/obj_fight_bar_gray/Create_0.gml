// Posição e tamanho da barra
bar_x = 292+80+490;
bar_y = 519;
bar_width = 240;
bar_height = 150;

// Ponteiro
pointer_x = bar_x;
pointer_speed = 2.7;

// Controle
hit_registered = false;
damage = 0;
miss = false;
going_back = false;

// Controle do ponteiro
pointer_width = 8;
hit_registered = false;
miss = false;

// Controle do piscar
blink_timer = 0;        // conta o tempo de piscar
blink_duration = 60;    // 60 frames = 1 segundo (se room_speed = 60)

global.destroy_bar=0;
