if (invincible_timer <= 0)
{
    hp -= 1;
    //instance_destroy(other); // Destroi a bala que colidiu
    //invincible_timer = invincible_duration;
}
