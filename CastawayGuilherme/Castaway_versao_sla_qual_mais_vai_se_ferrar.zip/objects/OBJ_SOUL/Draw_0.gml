

// Efeito visual para invencibilidade (piscando)
if (invincible_timer > 0) {
    if (invincible_timer mod 10 < 5) {
        draw_self(); // Pisca a cada 5 frames
    }
} else {
    draw_self();
}


