global.player_Name= "Matt";
global.player_LV=1;
move_speed = 4;
hp = 30;
max_hp = 30;//30

Sstate= battle_states.turnoPlayer;
global.just_teleported = false;
invincible_timer = 0; // Temporizador de invencibilidade
invincible_duration = 60; // 60 frames (1 segundo de invencibilidade)
