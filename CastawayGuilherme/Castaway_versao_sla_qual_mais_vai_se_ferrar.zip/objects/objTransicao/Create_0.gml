pisca_total = 3;         // Quantas vezes vai piscar
pisca_atual = 0;         // Quantos já piscou
pisca_tempo = 6;         // Quanto tempo cada piscada dura (em frames)
pisca_timer = pisca_tempo;
tela_pretaliga = false;  // Está preto ou não

proxima_room = BattleRoom;  // Substitua pela room desejada
