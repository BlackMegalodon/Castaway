pisca_timer -= 1;

if (pisca_timer <= 0) {
    tela_pretaliga = !tela_pretaliga;  // Alterna entre preto e normal
    pisca_timer = pisca_tempo;

    if (!tela_pretaliga) {  // Contabiliza só quando apaga
        pisca_atual += 1;
    }
}

if (pisca_atual >= pisca_total) {
    room_goto(BattleRoom);
}
