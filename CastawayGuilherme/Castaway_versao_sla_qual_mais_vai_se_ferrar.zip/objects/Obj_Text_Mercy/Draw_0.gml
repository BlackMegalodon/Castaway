// desenha apenas a parte do texto liberada
//draw_text(350, 450, string_copy(texto, 1, indice_letra));



if (ImWDGasterAndImSellecting==0) {
    
	if (global.can_spare==1) {
	draw_set_font(Font1_big); // uma font que você criou sem bold
    draw_set_color(c_yellow);
    draw_text(320,350,string_copy(name,1,indice_letra));
   
}
else {
	draw_set_font(Font1_big); // uma font que você criou sem bold
    draw_set_color(c_white);
    draw_text(320,350,string_copy(name,1,indice_letra));
   
}

// Coordenadas para a HUD
var bar_x = 600;
var bar_y = 352;
var bar_width = 80;
var bar_height = 15;



    
draw_set_color(c_red);
draw_rectangle(bar_x, bar_y, bar_x + bar_width , bar_y + bar_height , false);

// Desenhar a barra de vida (vermelha)
draw_set_color(c_lime);
var life_percentage = global.Bubble_HP / global.Bubblebee_maxHP;
draw_rectangle(bar_x, bar_y, bar_x + (bar_width * life_percentage), bar_y + bar_height, false);

  //}  

}

if (ImWDGasterAndImSellecting==1) {
	//------------------
if (global.can_spare==1) {
	draw_set_font(Font1_big); // uma font que você criou sem bold
    draw_set_color(c_yellow);
    draw_text(320,350,string_copy(texto,1,indice_letra));
    draw_set_color(c_white);
    draw_text(320,388,string_copy(texto2,1,indice_letra));
}
else {
	draw_set_font(Font1_big); // uma font que você criou sem bold
    draw_set_color(c_white);
    draw_text(320,350,string_copy(texto,1,indice_letra));
    draw_text(320,388,string_copy(texto2,1,indice_letra));
}

}



/*if (global.Spare_Flee_bruh==1) {
	draw_set_font(Font1_big); // uma font que você criou sem bold
    draw_set_color(c_white);
    draw_text(320,350,string_copy(texto,1,indice_letra));
    draw_set_color(c_yellow);
    draw_text(320,388,string_copy(texto2,1,indice_letra));
}

//draw_text(320,420,global.Spare_Flee_bruh);