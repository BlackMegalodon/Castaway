if (!variable_global_exists("current_music")) {
    global.current_music = noone;
}

