instance_destroy(Obj_Text_btl);
instance_destroy(Obj_Text_Mercy); 

global.Turnos=3;


if (!terminou) {
    timer += 1;
    if (timer >= velocidade) {
        timer = 0;
        indice_letra += 1; // adiciona mais uma letra
        if (indice_letra >= string_length(texto)) {
            indice_letra = string_length(texto);
            terminou = true; // acabou
        }
    }

  
        
}
