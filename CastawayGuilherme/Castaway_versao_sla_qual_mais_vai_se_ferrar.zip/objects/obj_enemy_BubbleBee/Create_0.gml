hp=120;
maxhp=120;
duracaoDeTurno=480
attack_index = 0;
already_attacked = false;
global.enemyHealthPoints = hp;
