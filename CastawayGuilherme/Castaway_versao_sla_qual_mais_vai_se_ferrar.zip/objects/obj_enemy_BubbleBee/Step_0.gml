if(global.enemyHealthPoints <=0){
instance_destroy(obj_enemy_BubbleBee)
objPlayer.state=states.neutro;
Script_Load()
};



if (OBJ_SOUL.Sstate == battle_states.turnoInimigo)
{
    // se o ataque ainda não começou
    if (!already_attacked)
    {
        already_attacked = true;

        attack_index++;
        if (attack_index > 3) attack_index = 1;

        duracaoDeTurno = 480;

        switch (attack_index)
        {
            case 1:
                // cria UMA VEZ
                for (var i = 0; i < 8; i++)
                {
                    var bubble = instance_create_layer(0, 0, "Instances", obj_bulletBubble);
                    bubble.angle = i * 45;
                }

                instance_create_layer(980, 320, "Instances", obj_kamikazeBubble);
            break;

            case 2:
					obj_battlebox.top = 230;//280
				    obj_battlebox.bottom =460
				    obj_battlebox.left =580 
				    obj_battlebox.right=700
                instance_create_layer(980, 320, "Instances", obj_kamikazeBubble);
            break;

            case 3:
                var bubble = instance_create_layer(0, 0, "Instances", obj_bulletBubble);
            break;
        }
    }

    // diminui o tempo (todo frame)
    duracaoDeTurno--;

    // quando acabar o tempo
    if (duracaoDeTurno <= 0)
    {
        // destrói TODAS as balas desse tipo
        with (obj_bulletBubble) instance_destroy();
        with (obj_kamikazeBubble) instance_destroy();

        OBJ_SOUL.Sstate = battle_states.turnoPlayer;
    }
}
else
{
    already_attacked = false;
}




