// obj_blaster_controller - Draw Event (ou Draw GUI para overlay fixa)
draw_self(); // se tiver sprite de preparação

if (instance_exists(target)) {
    // linha do centro até o player (telegraph)
    var tx = target.x;
    var ty = target.y;
    draw_set_alpha(telegraph_alpha);
    draw_set_color(c_red); // muda cor se quiser
    draw_line_width(x-17, y+9, tx, ty, 1); // se GMS ter draw_line_width
    // Se não tiver draw_line_width, usa draw_line
    // draw_line(x, y, tx, ty);
    draw_set_alpha(1);
}
