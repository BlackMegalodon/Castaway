// Step Event do obj_blaster_controller

// Verifica se o player (obj_soul) existe
if (instance_exists(OBJ_SOUL)) {
    var tx = OBJ_SOUL.x+26;
    var ty = OBJ_SOUL.y+2;

    // Calcula a direção do blaster até a alma
    var dir = point_direction(x, y, tx, ty);

    // Faz o sprite girar para olhar na direção
    image_angle = dir;
}
