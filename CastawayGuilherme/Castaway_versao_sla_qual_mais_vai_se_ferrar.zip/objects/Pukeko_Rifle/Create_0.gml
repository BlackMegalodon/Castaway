// obj_blaster_controller - Create Event
target = OBJ_SOUL;      // alvo padrão
charge_time = 100;         // ticks de telegraph
telegraph_alpha = 0.6;
shoot_count = 10;          // quantos projéteis em um burst (para spread)
spread_angle = 30;        // ângulo total do spread (graus)
bullet_speed = 4;
bullet_life = 180;
pattern = "spread";       // "single", "spread", "ring", "rotating"
rotating_angle = 0;       // usado por pattern "rotating"
rotating_speed = 2;       // graus por disparo
layer_to_spawn = "Instances"; // nome da layer para criar instâncias
alarm[0] = charge_time;

image_xscale=0.1;
image_yscale=0.1;