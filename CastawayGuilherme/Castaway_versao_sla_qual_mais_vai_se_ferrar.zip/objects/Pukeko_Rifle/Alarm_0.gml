// Alarm[0] - Disparo do blaster (versão sem frac/lerp)

// segurança: se não houver alvo, cancela
if (!instance_exists(target)) {
    instance_destroy();
    exit;
}

// valores de segurança
var n_shoot = max(1, floor(shoot_count));
var center = point_direction(x, y, target.x, target.y);
var half = spread_angle * 0.5;
var step_angle;
var ang;
var b;

// padrão de disparo
switch (pattern) {
    case "single":
        b = instance_create_depth(x, y, 0, obj_pukeko_bullet);
        b.direction = center;
        b.speed = bullet_speed;
        b.life = bullet_life;
        b.homing = false;
        break;

    case "spread":
        if (n_shoot == 1) {
            // apenas 1 tiro central
            ang = center;
            b = instance_create_depth(x, y, 0, obj_pukeko_bullet);
            b.direction = ang;
            b.speed = bullet_speed;
            b.life = bullet_life;
            b.homing = false;
        } else {
            // múltiplos tiros em leque
            step_angle = spread_angle / (n_shoot - 1);
            ang = center - half;
            for (var i = 0; i < n_shoot; i++) {
                b = instance_create_depth(x, y, 0, obj_pukeko_bullet);
                b.direction = ang;
                b.speed = bullet_speed;
                b.life = bullet_life;
                b.homing = false;

                ang += step_angle;
            }
        }
        break;

    case "ring":
        step_angle = 360 / n_shoot;
        ang = rotating_angle;
        for (var i = 0; i < n_shoot; i++) {
            b = instance_create_depth(x, y, 0, obj_pukeko_bullet);
            b.direction = ang;
            b.speed = bullet_speed;
            b.life = bullet_life;
            b.homing = false;

            ang += step_angle;
        }
        break;

    case "rotating":
        ang = center + rotating_angle;
        b = instance_create_depth(x, y, 0, obj_pukeko_bullet);
        b.direction = ang;
        b.speed = bullet_speed;
        b.life = bullet_life;
        b.homing = false;

        rotating_angle += rotating_speed;
        break;
}

// destrói o controlador (só dispara uma vez)
instance_destroy();
