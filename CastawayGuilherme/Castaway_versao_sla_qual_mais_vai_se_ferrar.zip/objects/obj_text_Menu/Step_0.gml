



if (!terminou) {
    timer += 1;
    if (timer >= velocidade) {
        timer = 0;
        indice_letra += 1; // adiciona mais uma letra
        if (indice_letra >= string_length(texto)) {
            indice_letra = string_length(texto);
            terminou = true; // acabou
        }
    }

    
}

if (oPlayerTaJogandoOuSla==0) {

if (hyperSellectionPeak==0) {
    	
    	
 if (keyboard_check(ord("Z"))) {
    if (file_exists("save.ini")) {
    	Script_LoadPoint();
       
        if(yummers<2){
        	yummers+=1;
        }
        if (yummers==2) {
        	oPlayerTaJogandoOuSla=1
        }
        
        
    }
    else {
    room_goto(Plains)
        oPlayerTaJogandoOuSla=1
        
    }
        	
        }
    
}

if (hyperSellectionPeak==1) {
	if (keyboard_check_pressed(ord("Z"))) {
    	Script_Reset();
        //oPlayerTaJogandoOuSla=1
    }
}

if (keyboard_check_pressed(ord("A"))) {
	hyperSellectionPeak-=1;
}
if (keyboard_check_pressed(ord("D"))) {
	hyperSellectionPeak+=1;
}

if (hyperSellectionPeak==2) {
	hyperSellectionPeak=1
}
if (hyperSellectionPeak<0) {
	hyperSellectionPeak=0
}
}
