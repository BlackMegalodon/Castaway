texto = " Continue "; // texto completo
texto2= "    Reset "
indice_letra = 0;        // quantas letras já estão sendo mostradas
velocidade = 0;          // quantos steps entre cada letra
timer = 0;               // contador
terminou = false;        // se terminou de escrever

global.cursor_id = noone;
oPlayerTaJogandoOuSla=0;

hyperSellectionPeak=0;
 yummers=0;