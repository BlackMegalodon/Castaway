// Movimento

//image_blend = make_color_hsv((current_time div 10 + id) mod 255, 255, 255);

x += lengthdir_x(speed, direction);
y += lengthdir_y(speed, direction);

// Atualiza rotação
image_angle = direction;

// Destrói fora da tela
if (y > room_height + 32 || x < -32 || x > room_width + 32) instance_destroy();

// Vida útil
life -= 1;
if (life <= 0) instance_destroy();
