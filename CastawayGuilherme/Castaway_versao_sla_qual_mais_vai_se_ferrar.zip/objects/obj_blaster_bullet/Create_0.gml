// Configuração básica da bala
speed = irandom_range(1, 3);
direction = irandom_range(260, 280); // diagonal para baixo
life = room_speed * 4; // dura 4 segundos
image_angle = direction;
//image_blend = make_color_hsv(irandom(0, 255), 255, 255); // cor aleatória (efeito Asriel)
image_blend = make_color_rgb(irandom(255), irandom(255), irandom(255));
