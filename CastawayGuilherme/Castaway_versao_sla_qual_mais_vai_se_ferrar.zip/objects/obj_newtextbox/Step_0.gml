var confirm = keyboard_check_pressed(confirm_key);

text_progress = min(text_progress + text_speed, text_lenght);

if (text_progress == text_lenght) {
	if (confirm) {
		next()
	}
}
else if (confirm) {
	text_progress = text_lenght;
}