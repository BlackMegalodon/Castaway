name=global.Bubble_Name;
texto = "* Checar        "; // texto completo
texto2= obj_BubleBee.act1
texto3= obj_BubleBee.act2
texto4= obj_BubleBee.act3

indice_letra = 0;        // quantas letras já estão sendo mostradas
velocidade = 2;          // quantos steps entre cada letra
timer = 0;               // contador
terminou = false;        // se terminou de escrever


ImWDGasterAndImSellecting=0;