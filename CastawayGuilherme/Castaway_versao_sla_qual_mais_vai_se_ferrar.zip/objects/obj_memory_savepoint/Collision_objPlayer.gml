if (keyboard_check_pressed(ord("Z"))) {
	
global.interaction=1 //1==sim 0==nao
var cam = view_camera[0];
var view_x = camera_get_view_x(cam);
var view_y = camera_get_view_y(cam);
var view_w = camera_get_view_width(cam);
var view_h = camera_get_view_height(cam);

instance_create_layer(view_x,view_y,"Instances_1",obj_text_Savepoint)
instance_create_layer(view_x+120,view_y+25,"Instances_1",obj_text_Savepoint_1 )
//instance_create_layer(view_x+120,view_y+110,"Instances_1",obj_cursor)    
    
  
    
    
   /*  if (keyboard_check_pressed(ord("A"))) {
	global.savepointSelection+=1
    }
    
    if (keyboard_check_pressed(ord("D"))) {
	global.savepointSelection-=1
    }

    
    
    if (global.savepointSelection<0) {
    	global.savepointSelection=1
    }
    if (global.savepointSelection==2) {
    	global.savepointSelection=0
    }*/
    
}