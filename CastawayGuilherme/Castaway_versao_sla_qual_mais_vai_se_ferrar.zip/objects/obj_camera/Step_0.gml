// Centraliza a câmera no obj_player
var px = objPlayer.x;
var py = objPlayer.y;

var cam_width = camera_get_view_width(view_camera[0]);
var cam_height = camera_get_view_height(view_camera[0]);

// Calcula a posição da camera para centralizar no player
var cam_x = px - cam_width / 2;
var cam_y = py - cam_height / 2;

camera_set_view_pos(view_camera[0], cam_x, cam_y);
