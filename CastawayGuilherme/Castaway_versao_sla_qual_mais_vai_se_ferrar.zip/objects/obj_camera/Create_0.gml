// Cria uma camera e atribui à view
var cam_width = 400;
var cam_height = 240;

camera = camera_create_view(0, 0, cam_width, cam_height, 0, objPlayer, -1, -1, 0, 0);
view_camera[0] = camera;
