if (keyboard_check_pressed(ord("T"))) {
    Script_Save();
}
if (keyboard_check(ord("Y"))) {
    Script_Load();
}