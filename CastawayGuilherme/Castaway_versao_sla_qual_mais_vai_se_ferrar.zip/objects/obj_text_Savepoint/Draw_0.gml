var cam = view_camera[0];
var view_x = camera_get_view_x(cam);
var view_y = camera_get_view_y(cam);
var view_w = camera_get_view_width(cam);
var view_h = camera_get_view_height(cam);



// desenha apenas a parte do texto liberada
//draw_text(350, 450, string_copy(texto, 1, indice_letra));
if (thisisothuffbro==0) {
	


if (hyperSellectionPeak==0) {
	draw_set_font(Font_SMALL_clean); // uma font que você criou sem bold
    draw_set_color(c_white);
    draw_text(view_x+125,view_y+30,string(global.player_Name) + " LV" + string(objPlayer.level));
    draw_set_color(c_yellow);
    draw_text(view_x+125,view_y+110,string_copy(texto,1,indice_letra));
    draw_set_color(c_white);
    draw_text(view_x+125+70,view_y+110,string_copy(texto2,1,indice_letra));


}
	if (hyperSellectionPeak==1) {
	draw_set_font(Font_SMALL_clean); // uma font que você criou sem bold
    draw_set_color(c_white);
    draw_text(view_x+125,view_y+30,string(global.player_Name) + " LV" + string(objPlayer.level));
    draw_set_color(c_white);
    draw_text(view_x+125,view_y+110,string_copy(texto,1,indice_letra));
    draw_set_color(c_yellow);
    draw_text(view_x+125+70,view_y+110,string_copy(texto2,1,indice_letra));


}
	
}
  
  /*  
    if (global.savepointSelection==0) {
    	if (keyboard_check_pressed(ord("Z"))) {
        	Script_SavePoint();
        }
    }
    if (global.savepointSelection==1) {
    	if (keyboard_check_pressed(ord("Z"))) {
        	global.interaction=0;
           
            instance_destroy(obj_text_Savepoint)
            instance_destroy(obj_text_Savepoint_1)
            // Destruir a instância existente, se existir
        //if (instance_exists(global.cursor_id)) {
            instance_destroy(global.cursor_id);
       // }
        }
    }



     if (keyboard_check_pressed(ord("A"))) {
	global.savepointSelection+=1
    }
    
    if (keyboard_check_pressed(ord("D"))) {
	global.savepointSelection-=1
    }


 
    
    
    if (global.savepointSelection<0) {
    	global.savepointSelection=1
    }
    if (global.savepointSelection==2) {
    	global.savepointSelection=0
    }



// Criar nova instância e guardar a ID
if (global.savepointSelection == 0) {
     if (instance_exists(global.cursor_id)) {
        instance_destroy(global.cursor_id);
    }
    
    global.cursor_id = instance_create_layer(view_x + 126, view_y + 110, "Instances_2", obj_cursor);
}


else if (global.savepointSelection == 1) {
     if (instance_exists(global.cursor_id)) {
        instance_destroy(global.cursor_id);
    }
    
    global.cursor_id = instance_create_layer(view_x + 126 + 75, view_y + 110, "Instances_2", obj_cursor);
}









 