



if (!terminou) {
    timer += 1;
    if (timer >= velocidade) {
        timer = 0;
        indice_letra += 1; // adiciona mais uma letra
        if (indice_letra >= string_length(texto)) {
            indice_letra = string_length(texto);
            terminou = true; // acabou
        }
    }

    // Se o jogador apertar ENTER para “pular” o texto, mostra tudo:
    if (keyboard_check_pressed(ord("Z"))) {
        
        indice_letra = string_length(texto);
        terminou = true; }
        
}



 
if (keyboard_check_pressed(ord("A"))) {
	hyperSellectionPeak-=1;
}
if (keyboard_check_pressed(ord("D"))) {
	hyperSellectionPeak+=1;
}

if (hyperSellectionPeak==2) {
	hyperSellectionPeak=1
}
if (hyperSellectionPeak<0) {
	hyperSellectionPeak=0
}


if (hyperSellectionPeak==0) {
	 if (keyboard_check_pressed(ord("Z"))) {
        	Script_SavePoint();
        }
    
    
}
if (hyperSellectionPeak==1) {
     if (keyboard_check_pressed(ord("Z"))) {
        	global.interaction=0;
            hyperSellectionPeak=3;
        	instance_destroy(obj_text_Savepoint)
            instance_destroy(obj_text_Savepoint_1)
            thisisothuffbro=1;
        }
    
}