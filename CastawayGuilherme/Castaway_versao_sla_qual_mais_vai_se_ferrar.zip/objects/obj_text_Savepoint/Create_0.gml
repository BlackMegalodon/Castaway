texto = " Save      "; // texto completo
texto2= "    Cancel"
indice_letra = 0;        // quantas letras já estão sendo mostradas
velocidade = 2;          // quantos steps entre cada letra
timer = 0;               // contador
terminou = false;        // se terminou de escrever

global.cursor_id = noone;

hyperSellectionPeak=0;
thisisothuffbro=0;