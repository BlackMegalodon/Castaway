// desenha apenas a parte do texto liberada
//draw_text(350, 450, string_copy(texto, 1, indice_letra));

draw_set_font(Font1_big); // uma font que você criou sem bold
draw_set_color(c_white);
draw_text(320,350,string_copy(texto,1,indice_letra));

