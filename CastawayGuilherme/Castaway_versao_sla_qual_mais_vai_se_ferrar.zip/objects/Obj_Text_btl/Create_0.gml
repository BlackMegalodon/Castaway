//if (global.enemy == obj_BubleBee) { 


texto = "* A ennemy appeared!";// texto completo
indice_letra = 0;        // quantas letras já estão sendo mostradas
velocidade = 2;          // quantos steps entre cada letra
timer = 0;               // contador
terminou = false;        // se terminou de escrever
