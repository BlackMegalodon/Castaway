image_xscale=6
image_yscale=2.6
sprite_index=spr_boxbtl