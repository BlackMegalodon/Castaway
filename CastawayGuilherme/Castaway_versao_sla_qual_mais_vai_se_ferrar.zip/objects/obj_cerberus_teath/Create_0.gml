timer =0;
duration=140;