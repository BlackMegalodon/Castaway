/*if (timer<duration) {
	timer+=1
    y-=1;
}