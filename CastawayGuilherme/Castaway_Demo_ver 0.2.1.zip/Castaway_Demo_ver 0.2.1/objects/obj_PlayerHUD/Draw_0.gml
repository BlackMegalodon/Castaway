if(OBJ_SOUL.Sstate==battle_states.turnoPlayer){
	
	if(actionSelect == turnoPlayer.neutro && GactionSelect==turnoGray.neutro){
	if(keyboard_check_pressed(ord("D"))){
	selectCounter+=1	
	}


	if(keyboard_check_pressed(ord("A"))){
	selectCounter-=1	
	}}


if(selectCounter>1){
	selectCounter=0
}
if(selectCounter<0){
	selectCounter=1
}

	if(selectCounter==0){
		obj_hudBox.sprite_index=spr_boxbtlSelect
		if(keyboard_check_pressed(ord("Z"))){
		actionSelect=turnoPlayer.PlayerSelect
		}
		if(keyboard_check_pressed(ord("X"))){
		actionSelect=turnoPlayer.neutro
		}
		
	}
	if(selectCounter==1){
		obj_hudBox.sprite_index=spr_boxbtl
		if(keyboard_check_pressed(ord("Z"))){
		GactionSelect=turnoGray.GraySelect
		}
		if(keyboard_check_pressed(ord("X"))){
		GactionSelect=turnoGray.neutro
		}
		
	}
}
//-----------


// Coordenadas para a HUD
var bar_x = 385;
var bar_y = 590;
var bar_width = 180;
var bar_height = 20;

if(actionSelect==turnoPlayer.neutro){
	
//obj_hudBox.sprite_index=spr_boxbtl
	
// Desenhar o contorno da barra
draw_set_font(Font1)
draw_set_color(c_white);
draw_text(385, 557, string(global.player_Name)+" LV " + string(global.player_LV) );

if (OBJ_SOUL.hp > 0) {
	
draw_set_color(c_red);
draw_rectangle(bar_x, bar_y, bar_x + bar_width , bar_y + bar_height , false);

// Desenhar a barra de vida (vermelha)
draw_set_color(c_lime);
var life_percentage = OBJ_SOUL.hp / OBJ_SOUL.max_hp;
draw_rectangle(bar_x, bar_y, bar_x + (bar_width * life_percentage), bar_y + bar_height, false);


draw_set_font(Font1)
    if (OBJ_SOUL.hp>=10) {
    	draw_set_color(c_black);
        draw_text(450, 591, string(OBJ_SOUL.hp)+"/" + string(OBJ_SOUL.max_hp));
    }
else {
	draw_set_color(c_black);
        draw_text(450, 591, "0"+string(OBJ_SOUL.hp)+"/" + string(OBJ_SOUL.max_hp));
    }
  }
  
 }
 
if(actionSelect==turnoPlayer.PlayerSelect){
	
	obj_hudBox.sprite_index=spr_boxbtl	
	
	if(keyboard_check_pressed(ord("S"))){
	verticalCounter+=1	
	}

	if(keyboard_check_pressed(ord("W"))){
	verticalCounter-=1	
	}
	
if(verticalCounter>3){
	verticalCounter=0
}
if(verticalCounter<0){
	verticalCounter=3
}
	
	if(verticalCounter==0){
	draw_set_font(Font1_big)
	draw_set_color(c_yellow);
	draw_text(385, 527, "Attack" );
	draw_set_color(c_white)
	draw_text(385, 567, "Act" );
	draw_text(384, 607, "Item" );
	draw_text(385, 647, "Defend" );
	}
	if(verticalCounter==1){
	draw_set_font(Font1_big)
	draw_set_color(c_white)
	draw_text(385, 527, "Attack" );
	draw_set_color(c_yellow)
	draw_text(385, 567, "Nuh uh" );
	draw_set_color(c_white)
	draw_text(384, 607, "Item" );
	draw_text(385, 647, "Defend" );
	
	//teste
		if(keyboard_check_pressed(ord("Z"))){
		OBJ_SOUL.Sstate=battle_states.turnoInimigo
		actionSelect=turnoPlayer.neutro
		}
	}
	if(verticalCounter==2){
	draw_set_font(Font1_big)
	draw_set_color(c_white)
	draw_text(385, 527, "Attack" );
	draw_text(385, 567, "Act" );
	draw_set_color(c_yellow)
	draw_text(384, 607, "Item" );
	draw_set_color(c_white)
	draw_text(385, 647, "Defend" );
	}
	if(verticalCounter==3){
	draw_set_font(Font1_big)
	draw_set_color(c_white)
	draw_text(385, 527, "Attack" );
	draw_text(385, 567, "Act" );
	draw_text(384, 607, "Item" );
	draw_set_color(c_yellow)
	draw_text(385, 647, "Defend" );
	}
}

  //-----------

var Gbar_x = 880;
var Gbar_y = 590;

if(GactionSelect==turnoGray.neutro){
// Desenhar o contorno da barra
draw_set_font(Font1)
draw_set_color(c_white);
draw_text(880, 557,"Gray"+" LV " + string(global.player_LV) + string(selectCounter)+string(verticalCounter) );

if (OBJ_SOUL.hp > 0) {
	    
draw_set_color(c_red);
draw_rectangle(Gbar_x, Gbar_y, Gbar_x + bar_width , Gbar_y + bar_height , false);

// Desenhar a barra de vida (vermelha)
draw_set_color(c_lime);
var Glife_percentage = OBJ_SOUL.hp / OBJ_SOUL.max_hp;
draw_rectangle(Gbar_x, Gbar_y, Gbar_x + (bar_width * Glife_percentage), Gbar_y + bar_height, false);


draw_set_font(Font1)
    if (OBJ_SOUL.hp>=10) {
    	draw_set_color(c_black);
        draw_text(945, 591, string(OBJ_SOUL.hp)+"/" + string(OBJ_SOUL.max_hp));
    }
else {
	draw_set_color(c_black);
        draw_text(945, 591, "0"+string(OBJ_SOUL.hp)+"/" + string(OBJ_SOUL.max_hp));
    }
  }
  
}

if(GactionSelect==turnoGray.GraySelect){
	
	if(keyboard_check_pressed(ord("S"))){
	GverticalCounter+=1	
	}

	if(keyboard_check_pressed(ord("W"))){
	GverticalCounter-=1	
	}
	
if(GverticalCounter>3){
	GverticalCounter=0
}
if(GverticalCounter<0){
	GverticalCounter=3
}

if(GverticalCounter==0){
	draw_set_font(Font1_big)
	draw_set_color(c_yellow);
	draw_text(880, 527, "Magic" );
	draw_set_color(c_white)
	draw_text(880, 567, "Act" );
	draw_text(879, 607, "Item" );
	draw_text(880, 647, "Defend" );
	}
	if(GverticalCounter==1){
	draw_set_font(Font1_big)
	draw_set_color(c_white)
	draw_text(880, 527, "Magic" );
	draw_set_color(c_yellow);
	draw_text(880, 567, "Act" );
	draw_set_color(c_white)
	draw_text(879, 607, "Item" );
	draw_text(880, 647, "Defend" );
	}
	if(GverticalCounter==2){
	draw_set_font(Font1_big)
	draw_set_color(c_white)
	draw_text(880, 527, "Magic" );
	draw_text(880, 567, "Act" );
	draw_set_color(c_yellow);
	draw_text(879, 607, "Item" );
	draw_set_color(c_white)
	draw_text(880, 647, "Defend" );
	}
	if(GverticalCounter==3){
	draw_set_font(Font1_big)
	draw_set_color(c_white)
	draw_text(880, 527, "Magic" );
	draw_text(880, 567, "Act" );
	draw_text(879, 607, "Item" );
	draw_set_color(c_yellow);
	draw_text(880, 647, "Defend" );
	
	}

}

 