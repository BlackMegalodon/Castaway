 instance_create_layer(192, 511, "Instances", obj_MattBtl);
  instance_create_layer(179, 500, "Instances", obj_hudBox);
   instance_create_layer(672, 500, "Instances", obj_GrayhudBox);
 instance_create_layer(687, 511, "Instances", obj_GrayBtl);
 
 selectCounter= 0;
 actionSelect=turnoPlayer.neutro
 GactionSelect=turnoGray.neutro
 verticalCounter=0;
 GverticalCounter=0