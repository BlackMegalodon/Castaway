enum states{
neutro,
interagindo,
estadoQueEvaporaOPlayerDaExistencia,
batata,
transicaoDeBatata
};


enum gray_states{
	follow,
	crawling,
	neutro
	
};


enum battle_states{
	turnoPlayer,
	turnoInimigo
};


enum turnoPlayer{
	neutro,
	PlayerSelect,
	
};
enum turnoGray{
	neutro,
	GraySelect
}