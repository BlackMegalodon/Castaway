if(OBJ_SOUL.Sstate== battle_states.turnoInimigo){
draw_set_color(c_white);

// Topo
draw_rectangle(left, top, right, top + border_thickness, false);

// Base
draw_rectangle(left, bottom - border_thickness, right, bottom, false);

// Esquerda
draw_rectangle(left, top, left + border_thickness, bottom, false);

// Direita
draw_rectangle(right - border_thickness, top, right, bottom, false);

//draw_text(0,0,string(top));
//draw_text(0,20,string(bottom));
//draw_text(0,40,string(left));
//draw_text(0,60,string(right));
}