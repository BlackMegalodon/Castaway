oneTimeCounter=0;
duracaoDeTurno=480