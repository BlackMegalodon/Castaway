
if(OBJ_SOUL.Sstate==battle_states.turnoInimigo){

if(oneTimeCounter==0){

	if(duracaoDeTurno>0){
		 duracaoDeTurno-=1
	 }

	var bubblecirc_1 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
	 bubblecirc_1.angle=0;
 
	  var bubblecirc_2 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
	 bubblecirc_2.angle=45;
 
	  var bubblecirc_3 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
	 bubblecirc_3.angle=90;
 
	  var bubblecirc_4 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
	 bubblecirc_4.angle=135;
 
	  var bubblecirc_5 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
	 bubblecirc_5.angle=180;
 
	  var bubblecirc_6 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
	 bubblecirc_6.angle=225;
 
	  var bubblecirc_7 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
	 bubblecirc_7.angle=270;
 
	  var bubblecirc_8 = instance_create_layer(0,0, "Instances", obj_bulletBubble);
	 bubblecirc_8.angle=315;
        
	 var kamikaze = instance_create_layer(980,320,"Instances",obj_kamikazeBubble);


	 if(duracaoDeTurno==0){
	instance_destroy(obj_bulletBubble);	
	instance_destroy(obj_kamikazeBubble);	
	OBJ_SOUL.Sstate=battle_states.turnoPlayer
	}

}
oneTimeCounter=1


}

