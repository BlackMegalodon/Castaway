if (OBJ_SOUL.Sstate == battle_states.turnoPlayer)
{
    switch(menu_state)
    {
        case player_menu_state.escolher_coluna:

            if (keyboard_check_pressed(ord("D"))) selectCounter++;
            if (keyboard_check_pressed(ord("A"))) selectCounter--;

            if (selectCounter > 1) selectCounter = 0;
            if (selectCounter < 0) selectCounter = 1;

            if (keyboard_check_pressed(ord("Z")))
            {
                if (selectCounter == 0)
                {
                    menu_state = player_menu_state.menu_ataques;
                    verticalCounter = 0;
                }
                else
                {
                    menu_state = player_menu_state.menu_gray;
                    GverticalCounter = 0;
                }
            }

        break;


        case player_menu_state.menu_ataques:

            if (keyboard_check_pressed(ord("S"))) verticalCounter++;
            if (keyboard_check_pressed(ord("W"))) verticalCounter--;

            if (verticalCounter > 3) verticalCounter = 0;
            if (verticalCounter < 0) verticalCounter = 3;

            if (keyboard_check_pressed(ord("Z")))
            {
                switch(verticalCounter)
                {
                    case 0:
					   // Attack
						menu_state=player_menu_state.player_hit;
						instance_create_layer(x,y,"Instances",obj_fight_bar)
                        //OBJ_SOUL.Sstate = battle_states.turnoInimigo;
                    break;

                    case 1:
                        // Act
                    break;

                    case 2:
                        // Item
                    break;

                    case 3:
                        // Defend
                    break;
                }

				//menu_state = player_menu_state.escolher_coluna;
            }

            if (keyboard_check_pressed(ord("X")))
                menu_state = player_menu_state.escolher_coluna;

        break;


        case player_menu_state.menu_gray:

            if (keyboard_check_pressed(ord("S"))) GverticalCounter++;
            if (keyboard_check_pressed(ord("W"))) GverticalCounter--;

            if (GverticalCounter > 3) GverticalCounter = 0;
            if (GverticalCounter < 0) GverticalCounter = 3;

            if (keyboard_check_pressed(ord("Z")))
            {
                switch(GverticalCounter)
                {
                    case 0:
                        // Magic
						menu_state=player_menu_state.gray_hit;
						instance_create_layer(x,y,"Instances",obj_fight_bar_gray)
                        //OBJ_SOUL.Sstate = battle_states.turnoInimigo;
                    break;

                    case 1:
                        // Act
                    break;

                    case 2:
                        // Item
                    break;

                    case 3:
                        // Defend
                    break;
                }

                menu_state = player_menu_state.escolher_coluna;
            }

            if (keyboard_check_pressed(ord("X")))
                menu_state = player_menu_state.escolher_coluna;

        break;
    }
}