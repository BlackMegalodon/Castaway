playerX=3;
playerY=251;

objPlayer.x=3;
objPlayer.y=251;