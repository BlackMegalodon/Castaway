playerX=3

playerY=590;

objPlayer.x=3;
objPlayer.y=590;