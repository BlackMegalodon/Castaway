global.PlayerTurn = false
global.Timer = 300*15//60==1segundo

global.interaction=0;


