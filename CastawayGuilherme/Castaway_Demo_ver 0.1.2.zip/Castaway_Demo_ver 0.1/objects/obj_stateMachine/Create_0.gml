enum states{
neutro,
interagindo,
estadoQueEvaporaOPlayerDaExistencia,
batata,
transicaoDeBatata
};

enum gray_states{
	follow,
	crawling
	
};	