

// Efeito visual para invencibilidade (piscando)
if (invincible_timer > 0) {
    if (invincible_timer mod 10 < 5) {
        draw_self(); // Pisca a cada 5 frames
    }
} else {
    draw_self();
}
// Coordenadas para a HUD
var bar_x = 825;
var bar_y = 575;
var bar_width = 100;
var bar_height = 20;

// Desenhar o contorno da barra
draw_set_font(Font1)
draw_set_color(c_white);
draw_text(335, 575, string(global.player_Name)+" LV " + string(global.player_LV) );

if (hp > 0) {
	draw_set_font(Font1)
    if (hp>=10) {
    	draw_set_color(c_white);
        draw_text(705, 575, "HP: " + string(hp)+"/" + string(max_hp));
    }
else {
	draw_set_color(c_white);
        draw_text(705, 575, "HP: " + "0"+string(hp)+"/" + string(max_hp));
    }

    
draw_set_color(c_red);
draw_rectangle(bar_x, bar_y, bar_x + bar_width , bar_y + bar_height , false);

// Desenhar a barra de vida (vermelha)
draw_set_color(c_yellow);
var life_percentage = hp / max_hp;
draw_rectangle(bar_x, bar_y, bar_x + (bar_width * life_percentage), bar_y + bar_height, false);

  }  

