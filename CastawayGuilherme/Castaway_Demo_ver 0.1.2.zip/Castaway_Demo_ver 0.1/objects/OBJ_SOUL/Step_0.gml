
if (global.Turnos==1) {
     //show_message("global.buttonSelect: " + string(global.buttonSelect));  // Debug

//if (tp_center==2) {
	

var _hor = keyboard_check(ord("D")) - keyboard_check(ord("A")); 
var _ver = keyboard_check(ord("S")) - keyboard_check(ord("W"));
	move_and_collide(_hor * move_speed, _ver * move_speed, obj_battlebox)
    //if (!place_meeting(x + _hor * move_speed, y, obj_battlebox)) {
     //   x += _hor * move_speed;
   // }
   // if (!place_meeting(x, y + _ver * move_speed, obj_battlebox)) {
//y += _ver * move_speed;
   // }

//move_and_collide(_hor * move_speed, _ver * move_speed, objPlayer); //volta pra player se nn der certo

 box = instance_nearest(x, y, obj_battlebox);
    

if (box != noone && global.Timer> -16) {
    if (x < box.left + box.border_thickness) x = box.left + box.border_thickness;
    if (x + sprite_width > box.right - box.border_thickness) x = box.right - box.border_thickness - sprite_width;
    if (y < box.top + box.border_thickness) y = box.top + box.border_thickness;
    if (y + sprite_height > box.bottom - box.border_thickness) y = box.bottom - box.border_thickness - sprite_height;
}
    

//}

}
//---------------------------

if (global.just_teleported) {
    alarm[0] = 10;
}

// Contador de invencibilidade
if (invincible_timer > 0) {
    invincible_timer -= 1;
}

if (hp<=0) {
	move_speed=0;
    instance_destroy(obj_battlebox);
    instance_destroy(global.enemy);
    instance_destroy(global.atk_enemy);
    //Script_Load();
    
  // sprite_index=Brk_soul
}

if (mercyOrsmt==0) {
	

    if (global.Turnos==0) {
        	
        

if (global.buttonCounter == 0 && global.buttonSelect==1) {
	 x = 315;
    y = 643;
    global.buttonCounter = 1;
}

if (global.buttonCounter == 1 && global.buttonSelect==1){ 
    x = 315;
    y = 643; 
}

if (global.buttonCounter == 2 && global.buttonSelect==1){ 
	 x = 491;
     y = 643;
    
     if (keyboard_check_pressed(ord("Z"))) {
         instance_destroy(Obj_Text_btl)
    	 instance_create_layer(530,092,"Instances",Obj_Text_ACT);
        
    }
    
    
}

if (global.buttonCounter == 3 && global.buttonSelect==1){ 
	 x = 673;
     y = 643;
}

if (global.buttonCounter == 4 && global.buttonSelect==1){ 
	 x = 842;
     y = 643;
}
        
    };
//---------------------------------------------------------------
if (global.Turnos==0) {
	//instance_destroy(global.atk_enemy);
   global.buttonSelect= 1;


if (keyboard_check_pressed(ord("D")) && global.buttonSelect==1) {
	global.buttonCounter = global.buttonCounter +1;
    if (global.buttonCounter > 4) {
    	global.buttonCounter = 1;
    }
}
if (keyboard_check_pressed(ord("A")) && global.buttonSelect==1) {
	global.buttonCounter = global.buttonCounter -1;
    if (global.buttonCounter < 1) {
    	global.buttonCounter = 4;
    }
}
    }}
if(atkCondition==1){
if (keyboard_check_pressed(ord("Z")) && global.buttonSelect==1 && global.buttonCounter ==1) {
    x=321;
    y=350;
    
    
    //instance_create_layer(100,265, "Instances",obj_fight_bar);
    atkCondition=0;
     instance_destroy(Obj_Text_btl)
     instance_create_layer(530,092,"Instances",Obj_Text_Attack);
    
    //global.Turnos=1;
}
}
    
    
 if(atkCondition==1){
if (keyboard_check_pressed(ord("Z")) && global.buttonSelect==1 && global.buttonCounter ==4) {
 
    
    instance_create_layer(530,092,"Instances",Obj_Text_Mercy)
    //x=321;
    //y=350;
    mercyOrsmt=1;
    atkCondition=0;
    
   
   
    //global.Turnos=1;
}
}


if (global.Turnos==2) {
    
    
	if(keyboard_check_pressed(ord("X"))){
        
        global.Turnos=0;
        mercyOrsmt=0;
        atkCondition=1;
        global.buttonSelect=1;
        instance_destroy(Obj_Text_Mercy);
    }
    
	/*if(keyboard_check_pressed(ord("S"))){
        
        global.Spare_Flee_bruh+=1; 
    }
    if(keyboard_check_pressed(ord("W"))){
        
        global.Spare_Flee_bruh-=1;
    }
    if (global.Spare_Flee_bruh<0) {
    	global.Spare_Flee_bruh=1;
    }
    
     if (global.Spare_Flee_bruh==2) {
    	global.Spare_Flee_bruh=0;
    }
     if (global.Spare_Flee_bruh==0) {
        x=321;
        y=350;
    }
    if (global.Spare_Flee_bruh==1) {
        x=321;
        y=388;
    }*/
    
}
if (global.Turnos==3) {
    
    
	if(keyboard_check_pressed(ord("X"))){
        
        global.Turnos=0;
        mercyOrsmt=0;
        atkCondition=1;
        global.buttonSelect=1;
        instance_destroy(Obj_Text_Attack);
    }
    
	if(keyboard_check_pressed(ord("S"))){
        
        global.Spare_Flee_bruh+=1; 
    }
    if(keyboard_check_pressed(ord("W"))){
        
        global.Spare_Flee_bruh-=1;
    }
    if (global.Spare_Flee_bruh<0) {
    	global.Spare_Flee_bruh=1;
    }
    
     if (global.Spare_Flee_bruh==2) {
    	global.Spare_Flee_bruh=0;
    }
     if (global.Spare_Flee_bruh==0) {
        x=321;
        y=350;
        if(keyboard_check_pressed(ord("Z"))){
            global.Turnos=0;
            instance_destroy(Obj_Text_Attack);
            instance_create_layer(1,1, "Instances",obj_fight_bar);
        }
    }
    if (global.Spare_Flee_bruh==1) {
        x=321;
        y=388;
    }
    
}       
    
    

if (global.Turnos==1) {
	
    global.buttonCounter=0;
    global.buttonSelect=0;
    atkCondition=0;
    
}
if (global.Turnos==1 && tp_center==0){
    x=647;
    y=455;
    tp_center=1; //marca que já teleportou
    
}
if (global.Timer==0) {
	atkCondition=1
    global.Timer = 300*15//60==1segundo
     tp_center=0;
}

