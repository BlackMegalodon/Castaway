instance_destroy(Obj_Text_btl)
instance_destroy(Obj_Text_Attack)

if (hit_registered || miss) {
    if (blink_timer < blink_duration) {
        blink_timer += 1;
    }
}

if (!hit_registered && !miss) {
    // Movimento do ponteiro
    pointer_x += pointer_speed;
    
    // Quando chega no fim da ida
    if (!going_back && pointer_x >= bar_x + bar_width) {
        pointer_speed *= -1; // volta
        going_back = true;
    }
    
    // Quando chega de volta no início
    if (going_back && pointer_x <= bar_x) {
        // Se não apertou nada -> MISS
        miss = true;
    }
    
    // Quando o jogador aperta espaço
    if (keyboard_check_pressed(vk_space)) {
        hit_registered = true;
        
        // Calcula quão perto do centro
        var center = bar_x + (bar_width / 2);
        var dist = abs(pointer_x - center);
        
        var max_damage = 100;
        damage = max_damage - dist;
        if (damage < 0) damage = 0;
            
               global.Bubble_HP=global.Bubble_HP-damage
    }
}

 instance_create_layer(305,316, "Instances",obj_hitbar);