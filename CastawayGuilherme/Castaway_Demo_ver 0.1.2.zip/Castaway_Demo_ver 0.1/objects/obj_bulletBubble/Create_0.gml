image_speed=0;
//image_yscale=1;
//image_xscale=1;


angle = 0;
move=0;
movemax=0;