global.enemy = 1;
global.Turnos =0; //(0=player / 1=enemy)
global.can_spare=0;
random_number = irandom_range(1, 15);

// vetor de pares [obj, peso]
 table = [
   [obj_Leaffy_Bellay_1, 40],
    [obj_Steallytittyes, 3000],
   [obj_BubleBee, 40],
    [obj_pukeko, 4]
];
randomize();


// soma pesos
 total = 0;
for (var i = 0; i < array_length(table); i++) total += table[i][1];

// sorteia
 r = irandom(total - 1);
 acum = 0;
chosen = obj_Leaffy_Bellay;
for (var i = 0; i < array_length(table); i++) {
    acum += table[i][1];
    if (r < acum) {
        chosen = table[i][0];
        break;
    }
}
show_debug_message("r = " + string(r));

instance_create_layer(530,092,"Instances_1", chosen);
global.enemy= chosen;



objPlayer.visible=false
OBJ_SOUL.visible=true