
/*if (random_number==1) {
  global.enemy = obj_BubleBee
	instance_create_layer(530,092,"Instances_1", obj_BubleBee);
}
if (random_number==2) {
   global.enemy = obj_BubleBee_1
	instance_create_layer(530,092,"Instances_1", obj_BubleBee_1);
}
if (random_number==3) {
   global.enemy = obj_BubleBee_2
	instance_create_layer(530,092,"Instances_1", obj_BubleBee_2);
} */



if (global.Turnos==0) {
	instance_destroy(global.atk_enemy);
    instance_destroy(global.atk_enemy2);
    //instance_destroy(global.atk_enemy);
    //instance_destroy(global.atk_enemy);
    obj_battlebox.top=311;
    obj_battlebox.bottom=561;
    obj_battlebox.left=300;
    obj_battlebox.right=980;
    instance_create_layer(530,092,"Instances",Obj_Text_btl);
}


if (global.Timer==0) {
	global.Turnos=0
    //global.Timer = 300*15//60==1segundo
}


if (global.Bubble_HP<=0) {
    objPlayer.can_move=true
    objPlayer.visible=true
	Script_Load();
}