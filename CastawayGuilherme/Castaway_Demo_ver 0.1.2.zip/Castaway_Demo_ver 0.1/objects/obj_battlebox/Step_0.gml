//if (keyboard_check(vk_up)) top += 2;          // Sobe a borda superior
//if (keyboard_check(vk_down)) bottom -= 2;     // Desce a borda inferior
//if (keyboard_check(vk_left)) left += 2;       // Expande a borda esquerda
//if (keyboard_check(vk_right)) right -= 2;     // Expande a borda direita

if (!instance_exists(obj_atkbutton) && !instance_exists(obj_atkbutton_1)) {
    instance_create_layer(287, 558, "Instances", obj_atkbutton);
}
if (!instance_exists(obj_actbutton) && !instance_exists(obj_actbutton_1)) {
    instance_create_layer(463, 558, "Instances", obj_actbutton);
}
if (!instance_exists(obj_itembutton) && !instance_exists(obj_itembutton_1)) {
    instance_create_layer(641, 558, "Instances", obj_itembutton);
}
if (!instance_exists(obj_mercybutton) && !instance_exists(obj_mercybutton_1)) {
    instance_create_layer(817, 558, "Instances", obj_mercybutton);
}

if (top > bottom - border_thickness) top = bottom - border_thickness;
if (left > right - border_thickness) left = right - border_thickness;

if (global.Timer > 0) {
    /*top += 1;
    bottom += 1;
    left -= 2.5; 
    right += 2.5;*/

    global.Timer -= 1;
} 
//if (global.Timer==limit) {
if (global.Timer == -16) {
    global.Turnos = 1;
}

if (global.Turnos==1) {
	 instance_destroy(obj_atkbutton);
     instance_destroy(obj_atkbutton_1);
     instance_destroy(obj_actbutton);
     instance_destroy(obj_actbutton_1);
     instance_destroy(obj_itembutton);
     instance_destroy(obj_itembutton_1);
     instance_destroy(obj_mercybutton);
     instance_destroy(obj_mercybutton_1);
    
     instance_create_layer(287, 558, "Instances", obj_atkbutton);
     instance_create_layer(463, 558, "Instances", obj_actbutton);
     instance_create_layer(641, 558, "Instances", obj_itembutton);
     instance_create_layer(817, 558, "Instances", obj_mercybutton)
}

if (global.buttonCounter == 1) {
    instance_destroy(obj_mercybutton_1);
    instance_create_layer(817, 558, "Instances", obj_mercybutton);

    instance_destroy(obj_atkbutton);
    instance_create_layer(287, 558, "Instances", obj_atkbutton_1);

    instance_destroy(obj_actbutton_1);
    instance_create_layer(463, 558, "Instances", obj_actbutton);
}
//if (keyboard_check(ord("D")) ) {
if (global.buttonCounter == 2) {
    instance_destroy(obj_atkbutton_1);
    instance_create_layer(287, 558, "Instances", obj_atkbutton);

    instance_destroy(obj_actbutton);
    instance_create_layer(463, 558, "Instances", obj_actbutton_1);
    //global.buttonCounter = 2;

    instance_destroy(obj_itembutton_1);
    instance_create_layer(641, 558, "Instances", obj_itembutton);
}

if (global.buttonCounter == 3) {
    instance_destroy(obj_actbutton_1);
    instance_create_layer(463, 558, "Instances", obj_actbutton);

    instance_destroy(obj_itembutton);
    instance_create_layer(641, 558, "Instances", obj_itembutton_1);
    // global.buttonCounter = 3; 

    instance_destroy(obj_mercybutton_1);
    instance_create_layer(817, 558, "Instances", obj_mercybutton);
}

if (global.buttonCounter == 4) {
    instance_destroy(obj_itembutton_1);
    instance_create_layer(641, 558, "Instances", obj_itembutton);

    instance_destroy(obj_mercybutton);
    instance_create_layer(817, 558, "Instances", obj_mercybutton_1);
    // global.buttonCounter = 3; 

    instance_destroy(obj_atkbutton_1);
    instance_create_layer(287, 558, "Instances", obj_atkbutton);
}
