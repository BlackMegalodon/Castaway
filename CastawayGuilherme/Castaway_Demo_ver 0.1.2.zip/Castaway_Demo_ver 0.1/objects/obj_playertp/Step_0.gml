/*if (global.just_teleported = true) {
	objPlayer.x = playerX
	objPlayer.y = playerY
	global.just_teleported = false
}
/*if (global.just_teleported2 = true) {
	objPlayer.x = playerX2
	objPlayer.y = playerY2
	global.just_teleported2 = false
}