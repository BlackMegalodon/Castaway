playerX = 1;
playerY = 1;
playerX2 = 1;
playerY2 = 1;
