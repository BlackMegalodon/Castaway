if(state==states.neutro){

var _hor = keyboard_check(ord("D")) - keyboard_check(ord("A")); 
var _ver = keyboard_check(ord("S")) - keyboard_check(ord("W"));
var _run = keyboard_check(vk_shift);


if(_run !=0){
	move_speed = 3.0}
	else {
		move_speed = 2};

move_and_collide(_hor * move_speed, _ver * move_speed, tilemap); 



if(_hor !=0 or _ver !=0 ){
    if(_ver > 0) sprite_index = spr_prt_front;
    else if(_ver < 0) sprite_index = spr_prt_back;
    else if(_hor > 0) sprite_index = spr_prt_right;
    else if(_hor < 0) sprite_index = spr_prt_left;        
}
 
else{
    if(sprite_index == spr_prt_front) sprite_index = spr_prt_front_idle;
    else if(sprite_index == spr_prt_back) sprite_index = spr_prt_back_idle;
    else if(sprite_index == spr_prt_right) sprite_index = spr_prt_right_idle;
    else if(sprite_index == spr_prt_left) sprite_index = spr_prt_left_idle;            
}



if (keyboard_check(ord("W")) || keyboard_check(ord("A")) || 
    keyboard_check(ord("S")) || keyboard_check(ord("D"))) {
    
    move_timer += 1;

    if (move_timer >= move_interval) {
        step_counter += 1;
        move_timer = 0;

        if (step_counter == random_number) {
            //show_message("teste "); move_speed = 0.0;
            instance_create_layer(x+6, y - 16, "Instances", objBaloon);
            Script_Save();
			state=states.transicaoDeBatata
					
}

else {
    move_timer = 0;  // Parou de andar → reseta temporizador
}

};
};
};
      

          /*  random_number = irandom_range(10, 20);
            step_counter = 0;
            alarm[1] = room_speed;*/
       
    
 

if(state==states.estadoQueEvaporaOPlayerDaExistencia){
	image_alpha=0;
};


if(state==states.transicaoDeBatata){
  //----INTERACTION I THINK
		
          if(sprite_index == spr_prt_front) sprite_index = spr_prt_front_idle;
   else if(sprite_index == spr_prt_back) sprite_index = spr_prt_back_idle;
   else if(sprite_index == spr_prt_right) sprite_index = spr_prt_right_idle;
   else if(sprite_index == spr_prt_left) sprite_index = spr_prt_left_idle;
   
    instance_create_layer(x+6, y - 16, "Instances_1", objTransicao);
	state=states.batata
};


if(state==states.interagindo){
  //----INTERACTION I THINK
		
          if(sprite_index == spr_prt_front) sprite_index = spr_prt_front_idle;
   else if(sprite_index == spr_prt_back) sprite_index = spr_prt_back_idle;
   else if(sprite_index == spr_prt_right) sprite_index = spr_prt_right_idle;
   else if(sprite_index == spr_prt_left) sprite_index = spr_prt_left_idle; 
};




//if (global.just_teleported) {
    // Após alguns frames, resetar
   // alarm[0] = 10; // 10 frames (~0.16s)
//}




