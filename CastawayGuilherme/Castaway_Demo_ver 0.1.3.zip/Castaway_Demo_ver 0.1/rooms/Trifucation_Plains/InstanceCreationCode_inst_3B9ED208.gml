playerX=3

playerY=590;

objPlayer.x=3;
objPlayer.y=590;
objPlayer.state=states.neutro;