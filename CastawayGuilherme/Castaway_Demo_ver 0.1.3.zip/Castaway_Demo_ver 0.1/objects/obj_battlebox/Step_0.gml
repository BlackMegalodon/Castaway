
if (top > bottom - border_thickness) top = bottom - border_thickness;
if (left > right - border_thickness) left = right - border_thickness;

if (global.Timer > 0) {
    /*top += 1;
    bottom += 1;
    left -= 2.5; 
    right += 2.5;*/

    global.Timer -= 1;
} 
//if (global.Timer==limit) {
if (global.Timer == -16) {
    global.Turnos = 1;
}


