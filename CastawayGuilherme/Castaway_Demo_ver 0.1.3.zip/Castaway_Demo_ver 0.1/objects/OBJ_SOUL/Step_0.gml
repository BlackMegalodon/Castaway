

   
	

var _hor = keyboard_check(ord("D")) - keyboard_check(ord("A")); 
var _ver = keyboard_check(ord("S")) - keyboard_check(ord("W"));
	move_and_collide(_hor * move_speed, _ver * move_speed, obj_battlebox)


 box = instance_nearest(x, y, obj_battlebox);
    

if (box != noone && global.Timer> -16) {
    if (x < box.left + box.border_thickness) x = box.left + box.border_thickness;
    if (x + sprite_width > box.right - box.border_thickness) x = box.right - box.border_thickness - sprite_width;
    if (y < box.top + box.border_thickness) y = box.top + box.border_thickness;
    if (y + sprite_height > box.bottom - box.border_thickness) y = box.bottom - box.border_thickness - sprite_height;
}
    

//}


//---------------------------

if (global.just_teleported) {
    alarm[0] = 10;
}

// Contador de invencibilidade
if (invincible_timer > 0) {
    invincible_timer -= 1;
}

