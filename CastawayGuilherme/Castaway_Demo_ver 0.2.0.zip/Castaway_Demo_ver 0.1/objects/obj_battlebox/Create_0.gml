
border_thickness = 3.9;


// Definir o tamanho da sala e da bullet board
room_width = 1280;
room_height = 720;

bullet_board_width = 600;
bullet_board_height = 250;

// Calcular o centro da sala
center_x = room_width / 2;
center_y = room_height -300;

// Calcular a posição de top e left para centralizar
left = center_x - (bullet_board_width / 2);
top = center_y - (bullet_board_height / 2);

// Calcular as posições de right e bottom com base nas posições de left e top
right = left + bullet_board_width;
bottom = top + bullet_board_height;

// Definir as variáveis do objeto para posicionamento
x = left; // Posição X (superior esquerda)
y = top;  // Posição Y (superior esquerda)

limit= -16;



   // top += 1*16;
   // bottom += 1*16;
   // left -= 2.5*16; 
    //right += 2.5*16;
    top = 280;
    bottom =490
    left =440 
    right=840
