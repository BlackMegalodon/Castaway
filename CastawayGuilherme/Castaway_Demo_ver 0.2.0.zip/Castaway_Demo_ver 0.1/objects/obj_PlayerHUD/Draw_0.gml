// Coordenadas para a HUD
var bar_x = 385;
var bar_y = 590;
var bar_width = 180;
var bar_height = 20;

// Desenhar o contorno da barra
draw_set_font(Font1)
draw_set_color(c_white);
draw_text(385, 557, string(global.player_Name)+" LV " + string(global.player_LV) );

if (OBJ_SOUL.hp > 0) {
	

    
draw_set_color(c_red);
draw_rectangle(bar_x, bar_y, bar_x + bar_width , bar_y + bar_height , false);

// Desenhar a barra de vida (vermelha)
draw_set_color(c_lime);
var life_percentage = OBJ_SOUL.hp / OBJ_SOUL.max_hp;
draw_rectangle(bar_x, bar_y, bar_x + (bar_width * life_percentage), bar_y + bar_height, false);


draw_set_font(Font1)
    if (OBJ_SOUL.hp>=10) {
    	draw_set_color(c_black);
        draw_text(450, 591, string(OBJ_SOUL.hp)+"/" + string(OBJ_SOUL.max_hp));
    }
else {
	draw_set_color(c_black);
        draw_text(450, 591, "0"+string(OBJ_SOUL.hp)+"/" + string(OBJ_SOUL.max_hp));
    }
  }  