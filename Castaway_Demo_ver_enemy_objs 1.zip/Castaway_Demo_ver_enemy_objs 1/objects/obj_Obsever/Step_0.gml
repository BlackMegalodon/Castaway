if(obj_room_trans.mpt==66){
	sprite_index=spr_observant_66
}

else{ sprite_index=spr_observant
	
};

