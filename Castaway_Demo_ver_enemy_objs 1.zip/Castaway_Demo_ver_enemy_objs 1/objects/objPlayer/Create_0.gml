move_speed = 2;
hp = 30;
max_hp = 30;
level = 1;
gold = 0;
playerroom = room
global.player_Name= "Matt";
state=states.neutro;
mask_index=spr_prt_front_idle

tilemap = layer_tilemap_get_id("Tiles_Collision");
tilemap2 = layer_tilemap_get_id("tiles_back");

random_number = irandom_range(10, 30);
step_counter = 0;

move_timer = 0;         // Controla o tempo andando
move_interval = room_speed / image_speed;  // Sincroniza com a animação → 15 frames
 can_move=true;
