if(global.enemyMercy >= 100){
instance_destroy(obj_enemy_Leaffy_Bellay)
objPlayer.state=states.neutro;
Script_Load()
};

if(global.enemyHealthPoints <=0){
instance_destroy(obj_enemy_Leaffy_Bellay)
objPlayer.state=states.neutro;
Script_Load()
};



if (OBJ_SOUL.Sstate == battle_states.turnoInimigo)
{
    // se o ataque ainda não começou
    if (!already_attacked)
    {
        already_attacked = true;

        attack_index++;
        if (attack_index > 2) attack_index = 1;

        duracaoDeTurno = 480;

        switch (attack_index)
        {
            case 1:
                // cria UMA VEZ
				var leaf = instance_create_layer(x+40, y, "Instances", obj_leafAttack); 
				
        obj_battlebox.left =490;
        obj_battlebox.right=760;
		obj_battlebox.top=351
              
            break;

            case 2:
				var leaf = instance_create_layer(x-200, y+320, "Instances", obj_pencileaf); 
 
   // instance_create_layer(x, y, "Instances", obj_blaster_rain_controller);
		obj_battlebox.left =490;
        obj_battlebox.right=760;
		obj_battlebox.top=351
            break;

           // case 3:
             //   var bubble = instance_create_layer(0, 0, "Instances", obj_bulletBubble);
            //break;
        }
    }

    // diminui o tempo (todo frame)
    duracaoDeTurno--;

    // quando acabar o tempo
    if (duracaoDeTurno <= 0)
    {
        // destrói TODAS as balas desse tipo
        with (obj_bulletBubble) instance_destroy();
        with (obj_kamikazeBubble) instance_destroy();

        OBJ_SOUL.Sstate = battle_states.turnoPlayer;
    }
}
else
{
    already_attacked = false;
}




