hp=120;
maxhp=120;
duracaoDeTurno=480
attack_index = 0;
already_attacked = false;
global.enemyHealthPoints = hp;
mercy=0
global.enemyMercy = mercy;

global.act1 = "Checar";
global.act2 = "Amassar";
global.act3 = "Desenhar";
global.act4 = "Cara Boba";

global.actValue1 = 0;
global.actValue2 = -100;
global.actValue3 = 100;
global.actValue4 = 50;
