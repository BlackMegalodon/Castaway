hp=120;
maxhp=120;
mercy=0;
duracaoDeTurno=480
attack_index = 0;
already_attacked = false;
global.enemyHealthPoints = hp;
global.enemyMercy = mercy;

global.act1 = "Checar";
global.act2 = "Assoprar";
global.act3 = "Estourar";
global.act4 = "* ";

global.actValue1 = 0;
global.actValue2 = 35.5;
global.actValue3 = 100;
global.actValue4 = 0;

