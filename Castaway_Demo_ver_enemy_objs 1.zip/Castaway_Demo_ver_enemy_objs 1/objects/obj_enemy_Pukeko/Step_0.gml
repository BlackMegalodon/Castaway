if(global.enemyMercy >= 100){
instance_destroy(obj_enemy_Pukeko)
objPlayer.state=states.neutro;
Script_Load()
};

if(global.enemyHealthPoints <=0){
instance_destroy(obj_enemy_Pukeko)
objPlayer.state=states.neutro;
Script_Load()
};


if (OBJ_SOUL.Sstate == battle_states.turnoInimigo)
{
    // se o ataque ainda não começou
    if (!already_attacked)
    {
        already_attacked = true;

        attack_index++;
        if (attack_index > 3) attack_index = 1;

        duracaoDeTurno = 480;

        switch (attack_index)
        {
            case 1:
                // cria UMA VEZ
				instance_destroy(obj_blaster_rain_controller)
                    var damn = instance_create_layer(585,40,"Instances",obj_kamikazeBubble_2);
					var damn_2 = instance_create_layer(585+50,40-150,"Instances",obj_kamikazeBubble_2);
					var damn_3 = instance_create_layer(585,40-300,"Instances",obj_kamikazeBubble_2);
     // var damn_32 = instance_create_layer(285,40-300,"Instances",obj_pukekoSniper);
					var damn_4 = instance_create_layer(585+50,40-450,"Instances",obj_kamikazeBubble_2);
      
	   
					var damn1 = instance_create_layer(585,40-600,"Instances",obj_kamikazeBubble_2);
			 //var damn_21 = instance_create_layer(585+50,40-750,"Instances",obj_kamikazeBubble);
					var damn_21 = instance_create_layer(585+300,40-750,"Instances",obj_pukekoSniper);
					var damn_31 = instance_create_layer(585,40-900,"Instances",obj_kamikazeBubble_2);
					var damn_41 = instance_create_layer(585+50,40-1050,"Instances",obj_kamikazeBubble_2);
	  
        
        obj_battlebox.left =600;
        obj_battlebox.right=680;
		obj_battlebox.top=251
		
            break;

            case 2:
					var c = instance_create_layer(x+400, y, "Instances", Pukeko_Rifle); 
   
c.target = OBJ_SOUL;
c.pattern = "spread";
c.shoot_count = 7;
c.spread_angle = 60;
c.charge_time = 45;
c.bullet_speed = 4;
c.bullet_life = 200;
    
 var f = instance_create_layer(x-100, y, "Instances", Pukeko_Rifle);
f.target = OBJ_SOUL;
f.pattern = "spread";
f.shoot_count = 7;
f.spread_angle = 60;
f.charge_time = 10;
f.bullet_speed = 1;
f.bullet_life = 200;

            break;

            case 3:
                  instance_create_layer(x, y, "Instances", obj_blaster_rain_controller);

        
        obj_battlebox.left = -6;
        obj_battlebox.right=1284;
		obj_battlebox.top=-2.90
        obj_battlebox.bottom=725
     
            break;
        }
    }

    // diminui o tempo (todo frame)
    duracaoDeTurno--;

    // quando acabar o tempo
    if (duracaoDeTurno <= 0)
    {
        // destrói TODAS as balas desse tipo
        with (obj_bulletBubble) instance_destroy();
        with (obj_kamikazeBubble) instance_destroy();

        OBJ_SOUL.Sstate = battle_states.turnoPlayer;
    }
}
else
{
    already_attacked = false;
}




