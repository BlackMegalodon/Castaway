hp=500;
maxhp=500;
duracaoDeTurno=480
attack_index = 0;
already_attacked = false;
global.enemyHealthPoints = hp;

mercy=0;
global.enemyMercy = mercy;

global.act1 = "Checar";
global.act2 = "Implorar";
global.act3 = "Rezar";
global.act4 = "Confrontar";

global.actValue1 = 0;
global.actValue2 = 0;
global.actValue3 = 0;
global.actValue4 = 10;
