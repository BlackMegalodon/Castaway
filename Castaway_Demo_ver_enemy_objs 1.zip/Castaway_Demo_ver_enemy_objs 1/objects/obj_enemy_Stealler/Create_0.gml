hp=200;
maxhp=200;
duracaoDeTurno=480
attack_index = 0;
already_attacked = false;
global.enemyHealthPoints = hp;
image_speed=0

mercy=0;
global.enemyMercy = mercy;

global.act1 = "Checar";
global.act2 = "Roubar";
global.act3 = "Posar X2";
global.act4 = "Posar";

global.actValue1 = 0;
global.actValue2 = 10;
global.actValue3 = 33;
global.actValue4 = 13;

