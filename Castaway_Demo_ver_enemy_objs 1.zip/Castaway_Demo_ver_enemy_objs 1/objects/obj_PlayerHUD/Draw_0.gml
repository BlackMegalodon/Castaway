// ----------------------------
// PLAYER HUD
// ----------------------------

var bar_x = 385;
var bar_y = 590;
var bar_width = 180;
var bar_height = 20;

if(menu_state != player_menu_state.menu_ataques){
	if(menu_state!=player_menu_state.player_hit){
draw_set_font(Font1);
draw_set_color(c_white);
draw_text(385, 557, string(global.player_Name) + " LV " + string(global.player_LV));

// Barra vermelha (contorno)
draw_set_color(c_red);
draw_rectangle(bar_x, bar_y, bar_x + bar_width, bar_y + bar_height, false);

// Barra verde (vida)
draw_set_color(c_lime);
var life_percentage = OBJ_SOUL.hp / OBJ_SOUL.max_hp;
if(OBJ_SOUL.hp<0){OBJ_SOUL.hp=0};
draw_rectangle(bar_x, bar_y, bar_x + (bar_width * life_percentage), bar_y + bar_height, false);

// texto HP
draw_set_font(Font1);
draw_set_color(c_black);
draw_text(450, 591, string(OBJ_SOUL.hp) + "/" + string(OBJ_SOUL.max_hp));
	}
	else{
	
	}
}

// ----------------------------
// GRAY HUD
// ----------------------------
var Gbar_x = 880;
var Gbar_y = 590;

if(menu_state != player_menu_state.menu_gray){
	if(menu_state != player_menu_state.gray_hit){
draw_set_font(Font1);
draw_set_color(c_white);
draw_text(880, 557, "Gray LV " + string(global.player_LV));


// contorno
draw_set_color(c_red);
draw_rectangle(Gbar_x, Gbar_y, Gbar_x + bar_width, Gbar_y + bar_height, false);

// vida
draw_set_color(c_lime);
var Glife_percentage = OBJ_SOUL.hp / OBJ_SOUL.max_hp;
draw_rectangle(Gbar_x, Gbar_y, Gbar_x + (bar_width * Glife_percentage), Gbar_y + bar_height, false);

// texto HP
draw_set_font(Font1);
draw_set_color(c_black);
draw_text(945, 591, string(OBJ_SOUL.hp) + "/" + string(OBJ_SOUL.max_hp));
	}
}

// ===================================================
// DESENHAR MENUS DEPENDENDO DO ESTADO
// ===================================================
if (OBJ_SOUL.Sstate == battle_states.turnoPlayer)
{
    switch(menu_state)
    {
        // -------------------------------------------
        case player_menu_state.escolher_coluna:
        // -------------------------------------------


            // player selecionado
            if (selectCounter == 0)
            {
				 obj_hudBox.sprite_index = spr_boxbtlSelect;
				 obj_GrayhudBox.sprite_index=spr_boxbtl
            }
            // gray selecionado
            else
            {
				 obj_hudBox.sprite_index = spr_boxbtl;
				 obj_GrayhudBox.sprite_index=spr_boxbtlSelect
            }

        break;


        // -------------------------------------------
        case player_menu_state.menu_ataques:
        // -------------------------------------------

         
			 obj_hudBox.sprite_index = spr_boxbtl;
            draw_set_font(Font1_big);

            // Attack
            draw_set_color(verticalCounter == 0 ? c_yellow : c_white);
            draw_text(385, 527, "Attack");

            // Act
            draw_set_color(verticalCounter == 1 ? c_yellow : c_white);
            draw_text(385, 567, "Act");

            // Item
            draw_set_color(verticalCounter == 2 ? c_yellow : c_white);
            draw_text(385, 607, "Item");

            // Defend
            draw_set_color(verticalCounter == 3 ? c_yellow : c_white);
            draw_text(385, 647, "Defend");

        break;


        // -------------------------------------------
        case player_menu_state.menu_gray:
        // -------------------------------------------

            obj_GrayhudBox.sprite_index = spr_boxbtl;

            draw_set_font(Font1_big);

            // Magic
            draw_set_color(GverticalCounter == 0 ? c_yellow : c_white);
            draw_text(880, 527, "Attack");

            // Act
            draw_set_color(GverticalCounter == 1 ? c_yellow : c_white);
            draw_text(880, 567, "Act");

            // Item
            draw_set_color(GverticalCounter == 2 ? c_yellow : c_white);
            draw_text(880, 607, "Magic");

            // Defend
            draw_set_color(GverticalCounter == 3 ? c_yellow : c_white);
            draw_text(880, 647, "Defend");

        break;
    }
}

 