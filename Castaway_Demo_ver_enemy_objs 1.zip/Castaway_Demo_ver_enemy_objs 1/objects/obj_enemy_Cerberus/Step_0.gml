if(global.enemyHealthPoints <=0){
instance_destroy(obj_enemy_Cerberus)
objPlayer.state=states.neutro;
Script_Load()
};



if (OBJ_SOUL.Sstate == battle_states.turnoInimigo)
{
    // se o ataque ainda não começou
    if (!already_attacked)
    {
        already_attacked = true;

        attack_index++;
        if (attack_index > 3) attack_index = 1;

        duracaoDeTurno = 480;

        switch (attack_index)
        {
            case 1:
                // cria UMA VEZ
				var atk = instance_create_layer(569, 173, "Instances", obj_bulletCerberus);
				var dir = point_direction(x, y, OBJ_SOUL.x + 70, OBJ_SOUL.y);
				atk.direction = dir;
				atk.speed = 6;
				var atk2 = instance_create_layer(529, 163, "Instances", obj_bulletCerberus);
				var dir2 = point_direction(x, y, OBJ_SOUL.x + 70, OBJ_SOUL.y);
				atk2.direction = dir;
				atk2.speed = 6;
				var atk3 = instance_create_layer(615, 209, "Instances", obj_bulletCerberus);
				var dir3 = point_direction(x, y, OBJ_SOUL.x + 70, OBJ_SOUL.y);
				atk3.direction = dir;
				atk3.speed = 6;
              
            break;

            case 2:
				var leaf = instance_create_layer(x-200, y+320, "Instances", obj_pencileaf); 
 
   // instance_create_layer(x, y, "Instances", obj_blaster_rain_controller);
		obj_battlebox.left =490;
        obj_battlebox.right=760;
		obj_battlebox.top=351
            break;

           // case 3:
             //   var bubble = instance_create_layer(0, 0, "Instances", obj_bulletBubble);
            //break;
        }
    }

    // diminui o tempo (todo frame)
    duracaoDeTurno--;

    // quando acabar o tempo
    if (duracaoDeTurno <= 0)
    {
        // destrói TODAS as balas desse tipo
        with (obj_bulletBubble) instance_destroy();
        with (obj_kamikazeBubble) instance_destroy();

        OBJ_SOUL.Sstate = battle_states.turnoPlayer;
    }
}
else
{
    already_attacked = false;
}




