 // Attack
         draw_set_font(Font1_big);
            draw_set_color(AverticalCounter == 0 ? c_yellow : c_white);
            draw_text(880, 527, global.act1);

            // Act
            draw_set_color(AverticalCounter == 1 ? c_yellow : c_white);
            draw_text(880, 567, global.act2);

            // Item
            draw_set_color(AverticalCounter == 2 ? c_yellow : c_white);
            draw_text(880, 607, global.act3);

            // Defend
            draw_set_color(AverticalCounter == 3 ? c_yellow : c_white);
            draw_text(880, 647, global.act4);