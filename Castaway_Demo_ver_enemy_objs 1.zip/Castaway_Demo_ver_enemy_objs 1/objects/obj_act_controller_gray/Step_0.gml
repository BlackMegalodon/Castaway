			if (keyboard_check_pressed(ord("S"))) AverticalCounter++;
            if (keyboard_check_pressed(ord("W"))) AverticalCounter--;

            if (AverticalCounter > 3) AverticalCounter = 0;
            if (AverticalCounter < 0) AverticalCounter = 3;

            if (keyboard_check_pressed(ord("Z")))
            {
                switch(AverticalCounter)
                {
                    case 0:
					   // Attack
						instance_destroy(obj_act_controller_gray)
						obj_PlayerHUD.menu_state=player_menu_state.escolher_coluna
                        //OBJ_SOUL.Sstate = battle_states.turnoInimigo;
						obj_PlayerHUD.selectCounter=0
						global.Player_Ready=true;
						OBJ_SOUL.Sstate = battle_states.turnoInimigo;
                    break;

                    case 1:
                        // Act
						obj_PlayerHUD.menu_state=player_menu_state.escolher_coluna
                        //OBJ_SOUL.Sstate = battle_states.turnoInimigo;
						obj_PlayerHUD.selectCounter=1
						global.Player_Ready=true;
						global.enemyMercy+=global.actValue2
						OBJ_SOUL.Sstate = battle_states.turnoInimigo;
						instance_destroy(obj_act_controller_gray)
							OBJ_SOUL.Sstate = battle_states.turnoInimigo;

						
                    break;

                    case 2:
                        // Item
						obj_PlayerHUD.menu_state=player_menu_state.escolher_coluna
                        //OBJ_SOUL.Sstate = battle_states.turnoInimigo;
						obj_PlayerHUD.selectCounter=0
						global.Player_Ready=true;
						global.enemyMercy+=global.actValue3
						instance_destroy(obj_act_controller_gray)
							OBJ_SOUL.Sstate = battle_states.turnoInimigo;
                    break;

                    case 3:
                        // Defend
						obj_PlayerHUD.menu_state=player_menu_state.escolher_coluna
                        //OBJ_SOUL.Sstate = battle_states.turnoInimigo;
						obj_PlayerHUD.selectCounter=0
						global.Player_Ready=true;
						global.enemyMercy+=global.actValue4
						instance_destroy(obj_act_controller_gray)
							OBJ_SOUL.Sstate = battle_states.turnoInimigo;
                    break;
                }
			}