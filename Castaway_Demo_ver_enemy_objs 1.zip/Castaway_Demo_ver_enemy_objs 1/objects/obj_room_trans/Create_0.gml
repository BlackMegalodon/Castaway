transition_state = 0;
counter = 0;
targetroom = 1; // Valor que será mudado no codigo de criação do Objeto
director = false;
global.PlayerCordx=0;
global.PlayerCordy=0
mpt=0;