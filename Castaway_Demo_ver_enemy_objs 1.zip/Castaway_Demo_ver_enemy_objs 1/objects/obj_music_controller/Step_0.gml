// Configurações de fade
var fade_speed = 0.02; // Velocidade do fade (quanto menor, mais suave)
var min_volume = 0.0;  // Volume mínimo
var max_volume = 1.0;  // Volume máximo

// Controle de transições
switch(room) {
    case Plains:
        if (global.current_music != Sound_planicies) {
            // Fade-out da música atual
            if (global.current_music != noone && audio_sound_get_gain(global.current_music) > min_volume) {
                audio_sound_gain(global.current_music, audio_sound_get_gain(global.current_music) - fade_speed, 0);
            } else {
                // Parar a música antiga e iniciar a nova com fade-in
                if (global.current_music != noone) {
                    audio_stop_sound(global.current_music);
                }
                global.current_music = Sound_planicies;
                audio_play_sound(global.current_music, true, 1);
                audio_sound_gain(global.current_music, min_volume, 0);
            }
        } else if (audio_sound_get_gain(global.current_music) < max_volume) {
            // Fade-in da nova música
            audio_sound_gain(global.current_music, audio_sound_get_gain(global.current_music) + fade_speed, 0);
        }
        break;

    case Trifucation_Plains:
        if (global.current_music != Sound_planicies) {
            // Fade-out da música atual
            if (global.current_music != noone && audio_sound_get_gain(global.current_music) > min_volume) {
                audio_sound_gain(global.current_music, audio_sound_get_gain(global.current_music) - fade_speed, 0);
            } else {
                // Parar a música antiga e iniciar a nova com fade-in
                if (global.current_music != noone) {
                    audio_stop_sound(global.current_music);
                }
                global.current_music = Sound_planicies;
                audio_play_sound(global.current_music, true, 1);
                audio_sound_gain(global.current_music, min_volume, 0);
            }
        } else if (audio_sound_get_gain(global.current_music) < max_volume) {
            // Fade-in da nova música
            audio_sound_gain(global.current_music, audio_sound_get_gain(global.current_music) + fade_speed, 0);
        }
        break;




    case BattleRoom:
        if (global.current_music != Sound_Cerberus) {
            if (global.current_music != noone && audio_sound_get_gain(global.current_music) > min_volume) {
                audio_sound_gain(global.current_music, audio_sound_get_gain(global.current_music) - fade_speed, 0);
            } else {
                if (global.current_music != noone) {
                    audio_stop_sound(global.current_music);
                }
                global.current_music = Sound_Cerberus;
                audio_play_sound(global.current_music, true, 1);
                audio_sound_gain(global.current_music, min_volume, 0);
            }
        } else if (audio_sound_get_gain(global.current_music) < max_volume) {
            audio_sound_gain(global.current_music, audio_sound_get_gain(global.current_music) + fade_speed, 0);
        }
    
   
        break;
}

