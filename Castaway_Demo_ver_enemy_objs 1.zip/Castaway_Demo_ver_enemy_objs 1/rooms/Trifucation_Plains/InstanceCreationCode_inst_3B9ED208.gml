playerX=225;

playerY=578;

//objPlayer.x=3;
//objPlayer.y=590;

