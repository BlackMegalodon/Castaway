mpt=irandom_range(50, 100)
mpt=66
if(mpt==66){
	targetroom=B_66
	global.PlayerCordx=630;
	global.PlayerCordy=705;
}
else{
	targetroom=Plains
	global.PlayerCordx=630;
	global.PlayerCordy=14;
}
