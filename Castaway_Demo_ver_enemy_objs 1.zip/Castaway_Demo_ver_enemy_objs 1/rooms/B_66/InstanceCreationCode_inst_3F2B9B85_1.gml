playerX=630;
playerY=745;