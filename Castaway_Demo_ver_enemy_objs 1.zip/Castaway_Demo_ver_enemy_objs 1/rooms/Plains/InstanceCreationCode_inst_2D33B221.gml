targetroom= Trifucation_Plains
global.PlayerCordx=245;
global.PlayerCordy=643